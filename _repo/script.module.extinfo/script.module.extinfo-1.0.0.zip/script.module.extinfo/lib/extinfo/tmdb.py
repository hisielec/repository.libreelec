import xbmcgui
import xbmc
import json
import requests

TMDB_API_KEY = "96e0692265de9b2019b16f0c144efa56"
LANGUAGE = "pt-BR"
API_ENDPOINT = "https://api.themoviedb.org/3"
IMG_ENDPOINT = "https://image.tmdb.org/t/p/"


def tmdb_get_image_url(path, size):
    return f"{IMG_ENDPOINT}/{size}{path}"


def tmdb_get_title_overview_translation(data, language="BR"):
    for translation in data["translations"]["translations"]:
        if translation["iso_3166_1"] == language:
            return {
                "title": translation["data"]["title"]
                if "title" in translation["data"]
                else translation["data"]["name"],
                "overview": translation["data"]["overview"],
            }

    return {"title": data["title"], "overview": data["overview"]}


def tmdb_actors(data):
    ret = []
    for cast in data["credits"]["cast"]:
        if cast["known_for_department"] == "Acting":
            ret.append(
                {
                    "name": cast["name"],
                    "role": cast["character"],
                    "thumbnail": tmdb_get_image_url(cast["profile_path"], "w300"),
                }
            )

    return ret


def tmdb_to_list_item(data, media_type):
    xbmc.log(json.dumps(data), xbmc.LOGINFO)
    trans = tmdb_get_title_overview_translation(data)
    li = xbmcgui.ListItem(label=trans["title"])
    info_tag = li.getVideoInfoTag()
    year_key = "release_date" if media_type == "movie" else "first_air_date"
    info_tag.setYear(int(data[year_key].split("-")[0]))
    info_tag.setMediaType("tvshow" if media_type == "tv" else "movie")
    info_tag.setTitle(trans["title"])
    if "original_title" in data:
        info_tag.setOriginalTitle(data["original_title"])

    if "runtime" in data:
        info_tag.setDuration(data["runtime"] * 60)
    else:
        info_tag.setDuration(data["episode_run_time"][0] * 60)
    info_tag.setPlot(trans["overview"])
    info_tag.setPlotOutline(trans["overview"])
    info_tag.setUniqueIDs(
        {"imdb": data["external_ids"]["imdb_id"], "tmdb": str(data["id"])}
    )
    info_tag.setGenres([genre["name"] for genre in data["genres"]])
    info_tag.setIMDBNumber(data["external_ids"]["imdb_id"])
    cast = tmdb_actors(data)
    info_tag.setCast(
        [
            xbmc.Actor(
                name=item["name"], role=item["role"], thumbnail=item["thumbnail"]
            )
            for item in cast
        ]
    )

    if "still_path" in data:
        li.setArt(
            {
                "poster": tmdb_get_image_url(data["still_path"], "w1280"),
                "fanart": tmdb_get_image_url(data["still_path"], "w1280"),
                "thumb": tmdb_get_image_url(data["still_path"], "w300"),
            }
        )
    else:
        li.setArt(
            {
                "poster": tmdb_get_image_url(data["poster_path"], "w1280"),
                "fanart": tmdb_get_image_url(data["backdrop_path"], "w1280"),
                "thumb": tmdb_get_image_url(data["poster_path"], "w300"),
            }
        )

    return li


def tmdb_get_episode(id, season, episode):
    url = f"{API_ENDPOINT}/tv/{id}/season/{season}/episode/{episode}?api_key={TMDB_API_KEY}&language={LANGUAGE}&append_to_response=credits,images,alternative_titles,translations,external_ids,trailers,release_dates"
    req = requests.get(url).json()

    return req


def tmdb_get_title_by_tmdb_id(id, media_type, season="", episode=""):
    url = f"{API_ENDPOINT}/{media_type}/{id}?api_key={TMDB_API_KEY}&language={LANGUAGE}&append_to_response=credits,images,alternative_titles,translations,external_ids,trailers,release_dates"
    req = requests.get(url).json()

    if season and episode:
        req = {**req, **tmdb_get_episode(id, season, episode)}

    return req


def tmdb_get_title_by_imdb_id(imdb_id, season="", episode=""):
    url = f"{API_ENDPOINT}/find/{imdb_id}?api_key={TMDB_API_KEY}&language={LANGUAGE}&external_source=imdb_id"
    req = requests.get(url).json()
    result = (
        req["movie_results"] if len(req["movie_results"]) > 0 else req["tv_results"]
    )

    if len(result) > 0:
        title = result[0]

        if title["media_type"] == "tv":
            info = tmdb_get_title_by_tmdb_id(
                title["id"], title["media_type"], season, episode
            )
        else:
            info = tmdb_get_title_by_tmdb_id(title["id"], title["media_type"])

        return tmdb_to_list_item(info, title["media_type"])

    return None
