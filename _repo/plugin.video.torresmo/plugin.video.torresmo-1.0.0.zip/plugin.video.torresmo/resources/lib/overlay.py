from xbmcgui import Window, ControlImage, ControlLabel
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmc
import os

ADDON = xbmcaddon.Addon()

ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_ICON = ADDON.getAddonInfo("icon")
ADDON_DATA = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

WINDOW_FULLSCREEN_VIDEO = 12005
WINDOW_HOME = 10000


class OverlayText(object):
    def __init__(self, w=0.5, h=0.15, y_offset=0, label_padding=15, label_h=43):
        window_width, window_height = self.get_resolution()
        self._window = Window(WINDOW_FULLSCREEN_VIDEO)
        self._shown = False
        total_label_h = 3 * label_h
        w = int(w * window_width)
        h = max(int(h * window_height), total_label_h + 2 * label_padding)
        x = (window_width - w) // 2
        y = int((3 * window_height / 4) - (h / 2) + 0.5) + y_offset
        label_x = x + label_padding
        label_w = w - 2 * label_padding
        label_y = y + int((h - total_label_h) / 2 + 0.5)
        self._label1 = ControlLabel(
            label_x, label_y, label_w, label_h, "", alignment=0x2 | 0x4
        )
        label_y += label_h
        self._label2 = ControlLabel(
            label_x, label_y, label_w, label_h, "", alignment=0x2 | 0x4
        )
        label_y += label_h
        self._label3 = ControlLabel(
            label_x, label_y, label_w, label_h, "", alignment=0x2 | 0x4
        )
        
        self._background = ControlImage(
            x,
            y,
            0,
            0,
            os.path.join(ADDON_PATH, "resources", "images", "black.png"),
            colorDiffuse="0xD0000000",
        )

        self._controls = [self._background, self._label1, self._label2, self._label3]

        self._background.setWidth(w)
        self._background.setHeight(h)

    def show(self):
        if not self._shown:
            self._window.addControls(self._controls)
        self._shown = True

    def hide(self):
        if self._shown:
            self._window.removeControls(self._controls)
        self._shown = False
        
    @property
    def shown(self):
        return self._shown

    def set_text2(self, label1=None, label2=None, label3=None):
        for label, control in ((label1, self._label1), (label2, self._label2), (label3, self._label3)):
            if label is not None:
                control.setLabel(label)

    def close2(self):
        self.hide()
        try:
            self.window.clearProperties()
        except Exception:
            pass

    # This is so hackish it hurts.
    def get_resolution(self):
        home = xbmcgui.Window(WINDOW_HOME)
        return home.getWidth(), home.getHeight()
