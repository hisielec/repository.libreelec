import os
import xbmc
import requests
import xbmcgui
import xbmcplugin
import urllib
import re
from resources.lib.api import (
    add_torrent,
    get_torrent_files,
    remove_torrent,
    get_torrent_info,
)
from resources.lib.route import Router
from resources.lib.player import TorresmoPlayer
from resources.lib.util import sizeof_fmt


plugin = Router()

video_file_extensions = (
    "avi",
    "mkv",
    "mp4",
    "flv",
)
dialog = xbmcgui.Dialog()


def filter_video_files(files):
    return [v for v in files if v["name"].endswith(video_file_extensions)]


def show_buffering(hash, name):
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Torresmo")
    monitor = xbmc.Monitor()
    while True:
        if monitor.waitForAbort(1):
            pDialog.close()
            return False
        # if player.playing:
        #     player.pause()
        torrent_info = get_torrent_info(hash)["torrent_status"]
        percent = int(torrent_info["progress"] * 100)
        pDialog.update(
            percent,
            f"{name}\n"
            + f"Baixado: {sizeof_fmt(torrent_info['total_done'])}\n"
            + f"Download: {sizeof_fmt(torrent_info['download_rate'])}/s\nProgresso: {percent}%",
        )

        if percent >= 99:
            pDialog.close()
            break

        if pDialog.iscanceled():
            pDialog.close()
            return False
    pDialog.close()
    return True


def filter_by_name(files, tmdbId):
    """ missing """
    return files


# ep_rgx = re.compile("(0{1,2}\d)\s")
season_ep_rgx = re.compile("S(\d+)E(\d+)", re.IGNORECASE)


def filter_by_season_episode(files, season="", episode=""):
    xbmc.log(season+ " | " +episode, xbmc.LOGINFO)
    if not episode and not season:
        return files

    filtered_files = []

    # for file in files:
    #     fileName = file["name"].replace(".", " ")
    #     m = re.search(ep_rgx, fileName)
    #     if m:
    #         if int(m[1]) == int(episode):
    #             filtered_files.append(file)

    # if len(filtered_files) == 1:
    #     return filtered_files

    for file in files:
        fileName = file["name"].replace(".", " ")
        m = re.search(season_ep_rgx, fileName)
        if m:
            season = int(m[1])
            episode = int(m[2])

            if episode == int(episode):  # and season = int(season)
                filtered_files.append(file)

    if len(filtered_files) == 0:
        return files
    return filtered_files


@plugin.route("/play_magnet")
def play_magnet(uri, tmdbId="", season="", episode="", key=""):
    i = 0
    success, hash = add_torrent(uri)
    if success:
        while True:
            files = get_torrent_files(hash)
            if files:
                break
            if xbmc.Monitor().waitForAbort(1) or i == 20:
                remove_torrent(hash)
                return
            i += 1

        video_files = filter_video_files(files)
        if len(video_files) > 1:
            video_files = filter_by_season_episode(video_files, season, episode)

        import json
        xbmc.log("video" + json.dumps(video_files), xbmc.LOGINFO)
        # if len(video_files) > 1:
        #     video_files = filter_by_name(video_files)

        num_video_files = len(video_files)
        if num_video_files > 1:
            names = [v["name"] for v in video_files]
            opt = dialog.select("Selecionar vídeo para reprodução:", names)
        elif num_video_files == 1:
            opt = 0
        else:
            opt = -1

        if opt >= 0:
            video_file = video_files[opt]
            with requests.get(video_file["stream"], stream=True) as r:
                for chunk in r.iter_content(chunk_size=8192):
                    break

            # play(key, video_file["stream"], hash)
            finished = show_buffering(hash, video_file["name"])
            if finished:
                play(key, video_file["stream"], hash)
            else:
                remove_torrent(hash)
        else:
            remove_torrent(hash)

    else:
        xbmc.log("Erro ao adicionar" + str(hash), xbmc.LOGINFO)


def play(key, link, hash):
    name = urllib.parse.unquote(os.path.basename(link))
    player = TorresmoPlayer(
        hash=hash, name=name, key=key
    )
    monitor = xbmc.Monitor()
    listitem = xbmcgui.ListItem(path=link)

    xbmcplugin.setResolvedUrl(plugin.handle, True, listitem)

    i = 0

    while True:
        if player.isPlayingVideo():
            break
        if monitor.waitForAbort(1):
            remove_torrent(hash)
            return
    
    # show_buffering(player, hash, name)

    # player.pause()

    while not monitor.abortRequested():
        if player.finished:
            break
        if monitor.waitForAbort(5):
            break
        
    remove_torrent(hash)


@plugin.route("/")
def index():
    li = xbmcgui.ListItem("Test")
    li.setProperty("isPlayable", "true")
    xbmcplugin.addDirectoryItem(
        handle=plugin.handle,
        listitem=li,
        isFolder=False,
        url=plugin.url_for(
            play_magnet,
            magnet="magnet:?xt=urn:btih:VMY6HVKLPJ2KELSUSJHW7HQLJYXECOQI&dn=Os%20Winchesters%20S01E01%20WEB-DL%201080p%20DUAL%205.1&tr=udp%3A%2F%2Ftracker.openbittorrent.com%3A80%2Fannounce",
        ),
    )
    xbmcplugin.endOfDirectory(plugin.handle)


def run():
    plugin.run()
