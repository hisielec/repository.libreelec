import sys
import urllib
import xbmc
import json

class Router:
    def __init__(self):
        self.map = {}
        self.handle = int(sys.argv[1])
        self.args = {}

    def get_first_arg(self, key):
        return self.args[key][0]

    def url_for(self, *args, **kwargs):
        return (
            sys.argv[0]
            + "?"
            + urllib.parse.urlencode({"mode": args[0].__name__, **kwargs})
        )

    def route(self, *args, **kwargs):
        def inner(func):
            """
            do operations with func
            """
            self.map[func.__name__] = func
            return func

        return inner  # this is the fun_obj mentioned in the above content

    def run(self, *args, **kwargs):
        args = sys.argv[2][1:]
        params = dict(urllib.parse.parse_qsl(args))
        self.args = {}
        xbmc.log("ROUTE: " + json.dumps(params), xbmc.LOGINFO)
        if params.get("mode"):
            mode = params.get("mode")
            del params["mode"]
            for k in params:
                if self.args.get(k):
                    self.args[k] = [params[k]]
                if isinstance(self, list):
                    self.args[k].append(params[k])
                else:
                    self.args[k] = params[k]
            self.map[mode](**self.args)
        else:
            self.map["index"]()
