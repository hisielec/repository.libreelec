import json
import requests
import xbmc
import urllib
import re
import xbmcaddon
import xbmcaddon
import zlib

ADDRESS = xbmcaddon.Addon().getSetting("server_torresmo")
PORT = "65225"

KB = float(1024)
MB = float(KB**2)
GB = float(KB**3)
TB = float(KB**4)

def humanize_bytes(B):   
  B = float(B)
  if B < KB:
      return "{0} B".format(B)
  elif KB <= B < MB:
      return "{0:.2f} KiB".format(B / KB)
  elif MB <= B < GB:
      return "{0:.2f} MiB".format(B / MB)
  elif GB <= B < TB:
      return "{0:.2f} GiB".format(B / GB)
  elif TB <= B:
      return "{0:.2f} TiB".format(B / TB)

"""
[
  {
    "hash": "0486c0cb81d12f744fdaeb1c24f31d03c3f03536",
    "name": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]",
    "size": 2111752409,
    "has_metadata": true,
    "is_memory_storage": true,
    "torrent_status": null
  }
]

"""

SERVER_M2 = xbmcaddon.Addon().getSetting("server_m2")

def get_key(hash, name):
  return hash + "_" + str(zlib.crc32(name.encode("utf-8")))

def post_playhead(site, key, head, total):
    resp = requests.post(
        f"http://{SERVER_M2}:9563/playhead",
        headers={"Content-Type": "application/json; charset=utf-8"},
        json={"site": site, "key": key, "head": head, "total": total},
    )
    xbmc.log(resp.text, xbmc.LOGINFO)
    

def list_torrents():
    x = requests.get(f"http://{ADDRESS}:{PORT}/torrents").json()

def pause_torrents():
    x = requests.get(f"http://{ADDRESS}:{PORT}/pause").json()


def resume_torrents():
    x = requests.get(f"http://{ADDRESS}:{PORT}/resume").json()


def remove_all_torrents():
    torrents = list_torrents()
    for torrent in torrents:
        remove_torrent(torrent.get("hash"))

def add_torrent(uri):
    x = requests.get(
        f"http://{ADDRESS}:{PORT}/service/add/uri?"
        + urllib.parse.urlencode({"uri": uri})
    ).json()

    xbmc.log("Adicionado " + uri + " " + json.dumps(x), xbmc.LOGINFO)

    if not x.get("success"):
        if "already exists" in x.get("error"):
            return True, re.search("'(.+?)'", x.get("error")).group(1)
        return False, ""

    return True, x.get("hash")

# {"success":true,"hash":"45599f84fb0288ce9723877ab648bf47d3d1c075","error":null}
def remove_torrent(hash):
    x = requests.get(f"http://{ADDRESS}:{PORT}/torrents/{hash}/remove").json()


"""
{
  "hash": "0486c0cb81d12f744fdaeb1c24f31d03c3f03536",
  "name": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]",
  "size": 2111752409,
  "has_metadata": true,
  "is_memory_storage": true,
  "torrent_status": {
    "total": 2111752409,
    "total_done": 156925952,
    "total_wanted": 125829120,
    "total_wanted_done": 125468672,
    "progress": 0.9971354166666667,
    "download_rate": 774808,
    "upload_rate": 8750,
    "state": 1,
    "state_string": "Forced downloading",
    "seeders": 68,
    "seeders_total": 2546,
    "peers": 76,
    "peers_total": 4722,
    "seeding_time": 0,
    "finished_time": 0,
    "active_time": 214,
    "total_download": 208337185,
    "total_upload": 18939012
  }
}"""
"""
[
  {
    "id": 0,
    "size": 30,
    "offset": 0,
    "path": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]/RARBG.txt",
    "name": "RARBG.txt",
    "stream": "http://192.168.1.66:65225/torrents/0486c0cb81d12f744fdaeb1c24f31d03c3f03536/files/0/stream/RARBG.txt",
    "file_status": null
  },
  {
    "id": 1,
    "size": 99,
    "offset": 30,
    "path": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]/RARBG_DO_NOT_MIRROR.exe",
    "name": "RARBG_DO_NOT_MIRROR.exe",
    "stream": "http://192.168.1.66:65225/torrents/0486c0cb81d12f744fdaeb1c24f31d03c3f03536/files/1/stream/RARBG_DO_NOT_MIRROR.exe",
    "file_status": null
  },
  {
    "id": 2,
    "size": 2111751327,
    "offset": 129,
    "path": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]/house.of.the.dragon.s01e08.720p.web.h264-cakes.mkv",
    "name": "house.of.the.dragon.s01e08.720p.web.h264-cakes.mkv",
    "stream": "http://192.168.1.66:65225/torrents/0486c0cb81d12f744fdaeb1c24f31d03c3f03536/files/2/stream/house.of.the.dragon.s01e08.720p.web.h264-cakes.mkv",
    "file_status": null
  },
  {
    "id": 3,
    "size": 953,
    "offset": 2111751456,
    "path": "House.of.the.Dragon.S01E08.720p.WEB.H264-CAKES[rarbg]/house.of.the.dragon.s01e08.720p.web.h264-cakes.nfo",
    "name": "house.of.the.dragon.s01e08.720p.web.h264-cakes.nfo",
    "stream": "http://192.168.1.66:65225/torrents/0486c0cb81d12f744fdaeb1c24f31d03c3f03536/files/3/stream/house.of.the.dragon.s01e08.720p.web.h264-cakes.nfo",
    "file_status": null
  }
]
"""

def download_file(hash, id):
    x = requests.get(f"http://{ADDRESS}:{PORT}/torrents/{hash}/files/id/download").json()
    return x

def get_torrent_files(hash):
    x = requests.get(f"http://{ADDRESS}:{PORT}/torrents/{hash}/files").json()

    return x

def get_torrent_info(hash):
    x = requests.get(f"http://{ADDRESS}:{PORT}/torrents/{hash}/info?status=true").json()

    return x
