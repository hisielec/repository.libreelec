import xbmc
from resources.lib.overlay import OverlayText
from resources.lib.api import get_torrent_info, get_key, post_playhead
from resources.lib.util import sizeof_fmt
import threading
import requests

    
class TorresmoPlayer(xbmc.Player):
    def __init__(self, key, hash, name):
        super(TorresmoPlayer, self).__init__()
        self.hash = hash
        self._monitor = xbmc.Monitor()
        self._stopped = False
        self._overlay = OverlayText()
        self._overlay_thread = threading.Thread(target=self._overlay_updater)
        self._overlay_thread.daemon = True
        self._overlay_thread.start()
        self._overlay.hide()
        self.head = 0
        self.total = 0
        self.finished = False
        self.name = name
        self.key = key
        self.playing = True

    def get_status_labels(self):
        status = get_torrent_info(self.hash)["torrent_status"]
        return self.name, "{:s} ({:.2f}%)".format(
            status["state_string"], status["progress"] * 100
        ), "D:{:s}/s U:{:s}/s S:{:d}/{:d} P:{:d}/{:d}".format(
            sizeof_fmt(status["download_rate"]),
            sizeof_fmt(status["upload_rate"]),
            status["seeders"],
            status["seeders_total"],
            status["peers"],
            status["peers_total"],
        )

    def onAVStarted(self):
        xbmc.log("onAVStarted", xbmc.LOGINFO)
        self._overlay.hide()

    def onPlayBackPaused(self):
        self.playing = False
        self.head = int(self.getTime())
        self.total = int(self.getTotalTime())
        post_playhead("torresmo", self.key, self.head, self.total)
        xbmc.log("onPlayBackPaused " + self.key, xbmc.LOGINFO)
        if self._overlay:
            self._overlay.show()
            self._update_overlay_text()

    def onPlayBackResumed(self):
        self.playing = True
        xbmc.log("onPlayBackResumed ", xbmc.LOGINFO)
        if self._overlay:
            self._overlay.hide()

    def onPlayBackEnded(self):
        post_playhead("torresmo", self.key, self.head, self.total)
        self._stopped = True
        self.stopped = True
        self.remove_torrent()

    def onPlayBackStopped(self):
        post_playhead("torresmo", self.key, self.head, self.total)
        self._stopped = True

    def _update_overlay_text(self):
        if self._overlay._shown:
            label1, label2, label3 = self.get_status_labels()
            self._overlay.set_text2(label1, label2, label3)

    def _overlay_updater(self):
        while not self._stopped:
            if self._overlay._shown:
                self._update_overlay_text()
            if self._monitor.waitForAbort(1):
                break
            try:
                self.head = int(self.getTime())
                self.total = int(self.getTotalTime())
            except Exception:
                pass
        self._overlay.close2()
        self.finished = True
