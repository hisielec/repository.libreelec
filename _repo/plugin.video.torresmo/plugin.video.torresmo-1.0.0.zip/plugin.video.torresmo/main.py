from resources.lib.plugin import run
import sys
import xbmcplugin

xbmcplugin.setContent(int(sys.argv[1]), "movies")
run()
