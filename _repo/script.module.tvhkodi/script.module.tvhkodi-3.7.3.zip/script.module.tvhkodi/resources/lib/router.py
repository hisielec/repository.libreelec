import sys
import urllib.parse
import json

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self


class Router:
    def __init__(self):
        self.map = {}
        self.handle = int(sys.argv[1])

    def url_for(self, *args, **kwargs):
        return (
            sys.argv[0]
            + "?"
            + urllib.parse.urlencode(
                {"mode": args[0].__name__, "data": json.dumps(kwargs)}
            )
        )

    def route(self, *args, **kwargs):
        def inner(func):
            self.map[func.__name__] = func
            return func

        return inner

    def run(self, *args, **kwargs):
        args = sys.argv[2][1:]
        params = dict(urllib.parse.parse_qsl(args))
        self.args = {}
        if params.get("mode"):
            mode = params.get("mode")
            del params["mode"]
            data_str = params.get("data")
            data = {}
            if data_str:
                data = json.loads(data_str)
            if "kwargs" in data:
                del data["kwargs"]
            self.map[mode](**data)
        else:
            self.map["index"]()
