import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin
from xbmcswift2 import Plugin
import requests
import os
import json
import uuid
import unicodedata
import re
import time
import urllib
import subprocess

plugin = Plugin()
dialog = xbmcgui.Dialog()

try:
    tvh_url_get = xbmcaddon.Addon("pvr.hts").getSetting("host")
    if tvh_url_get:
        xbmcaddon.Addon().setSetting(id="tvhurl", value=tvh_url_get)
    else:
        try:
            tvh_url = xbmcaddon.Addon().getSetting("tvhurl")
        except:
            xbmcaddon.Addon().setSetting(id="tvhurl", value="127.0.0.1")
    tvh_port_get = xbmcaddon.Addon("pvr.hts").getSetting("http_port")
    if tvh_port_get:
        xbmcaddon.Addon().setSetting(id="tvhport", value=tvh_port_get)
    else:
        try:
            tvh_port = xbmcaddon.Addon().getSetting("tvhport")
        except:
            xbmcaddon.Addon().setSetting(id="tvhport", value="9981")
except:
    pass

tvh_port = xbmcaddon.Addon().getSetting("tvhport")
tvh_usern = xbmcaddon.Addon().getSetting("usern")
tvh_passw = xbmcaddon.Addon().getSetting("passw")
if tvh_usern != "" and tvh_passw != "":
    tvh_url = tvh_usern + ":" + tvh_passw + "@" + xbmcaddon.Addon().getSetting("tvhurl")
else:
    tvh_url = xbmcaddon.Addon().getSetting("tvhurl")

try:
    check_url = "http://" + tvh_url + ":" + tvh_port + "/api/status/connections"
    check_load = requests.get(check_url)
    check_status = check_load.raise_for_status()
except requests.exceptions.HTTPError as err:
    dialog.ok(
        "Error",
        f"Tvheadend Access Error!\n{str(err)}\nPlease check your username/password in settings.",
    )
except requests.exceptions.RequestException as e:
    dialog.ok(
        "Error",
        "Tvheadend Access Error!\nCould not connect to Tvheadend server.\nPlease check your Tvheadend server is running or check the IP and port configuration in the settings.",
    )


re_word = re.compile("\W")


def clean_chan_name(ch):
    return re.sub(
        re_word,
        "",
        "".join(
            c.lower()
            for c in unicodedata.normalize("NFKD", ch.replace("+", "mais"))
            .encode("ascii", "ignore")
            .decode("ascii")
            if not c.isspace()
        ),
    )


def get_icon_path(icon_name):
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    return os.path.join(addon_path, "resources", "img", icon_name + ".png")


@plugin.route("/picons")
def picons():
    # picons by josemoraes99
    # https://github.com/josemoraes99/kodi_picons.git
    url_picon = "https://hk319yfwbl.execute-api.sa-east-1.amazonaws.com/prod"
    channels_url = (
        f"http://{tvh_url}:{tvh_port}/api/channel/grid?all=1&limit=999999999&sort=name"
    )
    channels = requests.get(channels_url).json()
    channel_name = set()

    for ch in channels["entries"]:
        channel_name.add(clean_chan_name(ch["name"]))

    payload = {"src": "kodi", "node": uuid.getnode(), "listChannel": list(channel_name)}
    headers = {"content-type": "application/json"}
    r = requests.post(url_picon, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    map_chan_url = {}
    xbmc.log(json.dumps(resp), xbmc.LOGINFO)
    for picons in resp["listaPicons"]:
        map_chan_url[picons[0]] = picons[1]

    for ch in channels["entries"]:
        name = clean_chan_name(ch["name"])
        url = map_chan_url[name]
        if url:
            param_url = (
                "http://"
                + tvh_url
                + ":"
                + tvh_port
                + '/api/idnode/save?node={"icon":"'
                + url
                + '","uuid":"'
                + ch["uuid"]
                + '"}'
            )
            requests.get(param_url)

    if dialog.yesno(
        "Picons atualizados!", "Deseja reiniciar kodi para efetuar as mudanças?"
    ):
        process = subprocess.Popen("systemctl restart kodi", shell=True, close_fds=True)
        process.wait()


def load_services():
    services_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/service/grid?start=0&limit=999999999&sort=multiplex"
    services_load = requests.get(services_url).json()

    return services_load


# http://192.168.1.74:9981/api/service/mapper/save


def services_param_load():
    services_url = "http://" + tvh_url + ":" + tvh_port + "/api/service/mapper/load"
    services_load = requests.get(services_url).json()
    services_opt_id = ["", ""]
    services_opt_label = ["", ""]
    services_node = {}
    for param in services_load["entries"][0]["params"]:
        serv_id = param["id"]
        if serv_id != "services":
            services_opt_id.append(serv_id)
            serv_label = param["caption"]
            services_opt_label.append(serv_label)
            serv_value_orig = param["value"]
            services_node[serv_id] = serv_value_orig
    return services_node


@plugin.route("/map_all_services")
def map_all_services():
    services = load_services()
    services_node = services_param_load()
    serv_total = services["total"]
    serv_uuid = []
    for serv_id in services["entries"]:
        if serv_id["channel"] == []:
            serv_uuid.append(serv_id["uuid"])
    serv_uuid_str = str(serv_uuid)
    serv_uuid_str = re.sub("u'", '"', serv_uuid_str)
    serv_uuid_str = re.sub("'", '"', serv_uuid_str)
    serv_node_str = json.dumps(services_node)
    serv_node_str = re.sub("{", "", serv_node_str)
    map_url = (
        "http://"
        + tvh_url
        + ":"
        + tvh_port
        + '/api/service/mapper/save?node={"services":'
        + serv_uuid_str
        + ","
        + serv_node_str
    )
    map_ch = requests.get(map_url)
    status_url = "http://" + tvh_url + ":" + tvh_port + "/api/service/mapper/status"
    time.sleep(3)
    map_status = requests.get(status_url).json()
    map_total_num = map_status["total"]
    map_ok_num = map_status["ok"]
    map_fail_num = map_status["fail"]
    map_ignore_num = map_status["ignore"]
    map_complete = map_ok_num + map_fail_num + map_ignore_num
    map_total_perc = (float(map_complete) / float(serv_total)) * 100
    dialog.ok(
        "Canais mapeados.",
        f"{map_ok_num} novos canais.\n{map_ignore_num} ignorados.",
    )


def scan_network(net_uuid_sel):
    adapters_url = f"http://{tvh_url}:{tvh_port}/api/hardware/tree?uuid=root"
    adapters_get = requests.get(adapters_url).json()
    if adapters_get == []:
        dialog.ok(
            "Tuner não configurado!",
            "Por favor, verifique configurações.",
        )
        return
    scan_url = (
        f"http://{tvh_url}:{tvh_port}/api/mpegts/network/scan?uuid={net_uuid_sel}"
    )
    update_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/grid"
    mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid"
    stream_url = f"http://{tvh_url}:{tvh_port}/api/status/inputs"
    mux_list_get = requests.get(mux_url).json()
    mux_list = [x["uuid"] for x in mux_list_get["entries"]]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Buscando canais...")
    scan = requests.get(scan_url).json()
    time.sleep(1)
    update = requests.get(update_url).json()
    update_scan = [
        x["scanq_length"] for x in update["entries"] if x["uuid"] == net_uuid_sel
    ]
    update_scan_num = update_scan[0]
    update_mux = [x["num_mux"] for x in update["entries"] if x["uuid"] == net_uuid_sel]
    update_mux_num = update_mux[0]
    orig_serv = [x["num_svc"] for x in update["entries"] if x["uuid"] == net_uuid_sel]
    orig_serv_num = orig_serv[0]
    update_serv_num = 0
    while update_scan_num > 0:
        update = requests.get(update_url).json()
        update_scan = [
            x["scanq_length"] for x in update["entries"] if x["uuid"] == net_uuid_sel
        ]
        update_scan_num = update_scan[0]
        update_serv = [
            x["num_svc"] for x in update["entries"] if x["uuid"] == net_uuid_sel
        ]
        update_serv_num = update_serv[0] - orig_serv_num
        update_scan_perc = 100 - (
            (float(update_scan_num) / float(update_mux_num)) * 100
        )
        update_stream = requests.get(stream_url).json()
        stream_freq_list = []
        stream_freq_list = [x.get("stream") for x in update_stream["entries"]]
        stream_freq = "  &  ".join(str(s) for s in stream_freq_list)
        pDialog.update(
            int(update_scan_perc),
            f"Buscando: {stream_freq}\nNovos serviços encontrados: {update_serv_num}",
        )
        time.sleep(1)
        if pDialog.iscanceled():
            mux_list_str = str(mux_list)
            mux_list_str = re.sub("u'", '"', mux_list_str)
            mux_list_str = re.sub("'", '"', mux_list_str)
            mux_stop_url = (
                "http://"
                + tvh_url
                + ":"
                + tvh_port
                + '/api/idnode/save?node={"scan_state":0,"uuid":'
                + mux_list_str
                + "}"
            )
            mux_stop = requests.get(mux_stop_url)
            dialog.ok("Busca cancelada", "Novos serviços não serão mapeados.")
            return
    pDialog.close()
    if update_serv_num == 0:
        dialog.ok(
            "Busca completa.",
            f"Novos serviços encontrados: {update_serv_num}.\n",
        )
        return
    goto_map = dialog.yesno(
        "Busca completa.",
        f"Novos serviços encontrados: {update_serv_num}.\nGostaria de mapear os canais para o Kodi ter acesso?",
    )
    if not goto_map:
        return
    map_all_services()


def select_network():
    api_path = "mpegts/network/grid"
    api_url = f"http://{tvh_url}:{tvh_port}/api/{api_path}"
    networks = requests.get(api_url).json()
    net_name = []
    net_uuid = []
    for net_n in networks["entries"]:
        net_name.append(net_n["networkname"])
    for net_u in networks["entries"]:
        net_uuid.append(net_u["uuid"])
    if len(net_name) == 1:
        return net_uuid[0]
    sel = dialog.select("Selecionar rede", list=net_name)
    if sel >= 0:
        return net_uuid[sel]
    else:
        return None


def mux_create(network_uuid, mfreq):
    mux_create_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/mux_create"
    data = {
        "uuid": network_uuid,
        "conf": json.dumps(
            {
                "enabled": 1,
                "epg": 1,
                "delsys": "DVB-C",
                "frequency": mfreq * 1000000,
                "symbolrate": "5217000",
                "constellation": "QAM/256",
                "fec": "AUTO",
                "plp_id": -1,
                "scan_state": 0,
                "charset": "ISO-8859-1",
                "tsid_zero": "false",
                "pmt_06_ac3": 0,
                "eit_tsid_nocheck": "false",
                "sid_filter": 0,
                "data_slice": 0,
            }
        ),
    }
    requests.post(mux_create_url, data=data)


def network_delete(uuid):
    network_delete_url = f"http://{tvh_url}:{tvh_port}/api/idnode/delete"
    data = {
        "uuid": json.dumps([uuid]),
    }
    requests.post(network_delete_url, data=data)


def network_create(name):
    network_create_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/create"
    data = {
        "class": "dvb_network_dvbc",
        "conf": json.dumps(
            {
                "networkname": name,
                "scanfile": "",
                "pnetworkname": "",
                "nid": 0,
                "autodiscovery": 1,
                "ignore_chnum": "false",
                "satip_source": 0,
                "charset": "ISO-8859-1",
                "skipinitscan": "true",
                "idlescan": "false",
                "sid_chnum": "false",
                "localtime": 0,
            }
        ),
    }

    requests.post(network_create_url, data=data)


def del_muxes():
    mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
    muxes = requests.get(mux_url).json()
    muxes_uuid = [x["uuid"] for x in muxes["entries"]]
    del_nodes(muxes_uuid)


@plugin.route("/conf_freq")
def conf_freq():
    network_uuid = select_network()
    if network_uuid:
        mfreq = dialog.input("Frequência em MHz: (Ex: 465)", type=xbmcgui.INPUT_NUMERIC)
        try:
            mfreq_num = int(mfreq)
            if mfreq_num >= 111 and mfreq_num <= 783:
                reset_channels(no_ask=True)
                del_muxes()

                mux_create(network_uuid, mfreq_num)
                # dialog.ok("Frequência adicionada!", "Frequência adicionada a rede.")
                scan_network(network_uuid)
            else:
                dialog.ok(
                    "Frequência inválida",
                    "Entre com frequência no intervalo 111 a 783 MHz.",
                )
        except:
            pass

    else:
        dialog.ok("Falha", "Configure rede no TVH.")


@plugin.route("/mux_scan")
def mux_scan():
    network_uuid = select_network()
    if network_uuid:
        scan_network(network_uuid)


def del_nodes(uuids):
    uuids_str = ",".join(f'"{x}"' for x in uuids)
    delete_node_url = f"http://{tvh_url}:{tvh_port}/api/idnode/delete"

    requests.post(delete_node_url, data={"uuid": f"[{uuids_str}]"})


def list_services():
    service_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/service/grid?start=0&limit=999999999&sort=svcname&dir=ASC"
    services = requests.get(service_url).json()
    return services


def list_channels():
    channels_url = f"http://{tvh_url}:{tvh_port}/api/channel/grid"

    channels = requests.post(
        channels_url,
        data={
            "start": "0",
            "limit": "999999999",
            "sort": "name",
            "dir": "ASC",
            "all": "1",
        },
    ).json()
    return channels


def del_freq_by_name(name):
    services = list_services()
    services_uuid = {}
    for sv_u in services["entries"]:
        services_uuid[sv_u["uuid"]] = sv_u

    channels = list_channels()
    num_chan_del = 0
    num_sv_del = 0
    del_uuids = []
    for ch_u in channels["entries"]:
        service = services_uuid[ch_u["services"][0]]
        if name in service["multiplex"]:
            del_uuids.append(ch_u["uuid"])
            num_chan_del += 1
    del_nodes(del_uuids)
    del_uuids = []
    for uuid in services_uuid:
        suid = services_uuid[uuid]
        if name in suid["multiplex"]:
            del_uuids.append(uuid)
            num_sv_del += 1
    del_nodes(del_uuids)

    return num_chan_del, num_sv_del


def map_services(mux):
    services = list_services()
    services_param = services_param_load()
    services_selected = []
    for sv in services["entries"]:
        if mux in sv["multiplex"]:
            services_selected.append(sv["uuid"])
    requests.post(
        f"http://{tvh_url}:{tvh_port}/api/service/mapper/save",
        data={
            "node": json.dumps(
                {
                    "services": json.dumps(services_selected),
                    **services_param,
                }
            )
        },
    )

    dialog.ok("Mapeados.", "Canais foram mapeados.")


@plugin.route("/mux_scan_freq")
def mux_scan_freq():
    network_uuid = select_network()
    if network_uuid:
        mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
        muxes = requests.get(mux_url).json()
        mux_list = [x for x in muxes["entries"] if x["network_uuid"] == network_uuid]
        list = [f'{x["network"]}/{x["name"]}' for x in mux_list]
        sel = dialog.select("Selecionar frequência:", list)
        if sel >= 0:
            mux = mux_list[sel]
            mux_name = mux["name"]
            if dialog.yesno(
                "Busca por frequência", "Apagar canais e serviços nesta frequência"
            ):
                del_freq_by_name(mux_name)
                time.sleep(1)
            pDialog = xbmcgui.DialogProgress()
            pDialog.create("Buscando canais...", "Por favor, aguarde...")
            time.sleep(1)
            requests.post(
                f"http://{tvh_url}:{tvh_port}/api/idnode/save",
                data={"node": json.dumps({"scan_state": 1, "uuid": mux["uuid"]})},
            )
            time.sleep(1)
            is_active = False
            while True:
                resp = requests.post(
                    "http://192.168.1.74:9981/api/idnode/load",
                    data={"uuid": json.dumps([mux["uuid"]]), "grid": 1},
                )
                json_resp = json.loads(resp.text)
                entry = json_resp["entries"][0]
                if pDialog.iscanceled():
                    pDialog.close()
                    break
                if entry["scan_state"] == 1:
                    time.sleep(1)
                    continue
                if not is_active and entry["scan_state"] == 2:
                    is_active = True
                    pDialog.update(50, f"Frequência: {mux_name}")
                    time.sleep(1)
                    continue
                if entry["scan_state"] == 0:
                    pDialog.update(100, "Busca finalizada!")
                    break
                time.sleep(1)
            update_serv_num = int(entry["num_svc"]) - int(entry["num_chn"])
            pDialog.close()
            if update_serv_num == 0:
                dialog.ok(
                    "Busca completa",
                    f"Serviços encontrados {entry['num_svc']}.\nNão há novos canais para serem mapeados",
                )
            goto_map = dialog.yesno(
                "Busca completa.",
                f"Total de serviços: {entry['num_svc']}.\nNovos canais encontrados: {update_serv_num}.\nGostaria de mapeá-los para Kodi ter acesso?",
            )

            if not goto_map:
                return

            map_services(mux_name)


@plugin.route("/reset_channels")
def reset_channels(no_ask=False):
    network_uuid = select_network()
    if network_uuid and (
        no_ask or dialog.yesno("Apagar canais", "Deseja apagar todos os canais?")
    ):
        xbmc.log("resetando canais", xbmc.LOGINFO)
        channels_url = (
            "http://"
            + tvh_url
            + ":"
            + tvh_port
            + "/api/channel/grid?all=1&limit=999999999&sort=name"
        )
        channels = list_channels()
        channels_uuid = []
        for ch_u in channels["entries"]:
            channels_uuid.append(ch_u["uuid"])
        del_nodes(channels_uuid)
        time.sleep(1)
        services = list_services()
        services_uuid = []
        for sv_u in services["entries"]:
            services_uuid.append(sv_u["uuid"])

        del_nodes(services_uuid)

        if not no_ask:
            dialog.ok("Finalizado.", "Canais foram apagados!")


@plugin.route("/reset_channels_freq")
def reset_channels_freq():
    network_uuid = select_network()
    if network_uuid:
        mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
        muxes = requests.get(mux_url).json()
        mux_list = [x for x in muxes["entries"] if x["network_uuid"] == network_uuid]
        list = [f'{x["network"]}/{x["name"]}' for x in mux_list]
        opt = dialog.select("Apagar canais em: ", list)
        if opt >= 0:
            name = mux_list[opt]["name"]
            num_chan_del, num_sv_del = del_freq_by_name(name)
            dialog.ok(
                "Finalizado.",
                f"{num_chan_del} canais apagados.\n({num_sv_del}) serviços apagados.\n",
            )


@plugin.route("/run_epg_grabber")
def run_epg_grabber():
    comet_poll_box_url = "http://" + tvh_url + ":" + tvh_port + "/comet/poll"
    comet_poll_box = requests.get(comet_poll_box_url).json()
    comet_poll_box_id = comet_poll_box["boxid"]
    epg_run_int_url = (
        "http://" + tvh_url + ":" + tvh_port + "/api/epggrab/internal/rerun?rerun=1"
    )
    epg_run_int = requests.get(epg_run_int_url).json()
    if epg_run_int == {}:
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("Atualizando epg...")
        comet_poll_url = (
            "http://"
            + tvh_url
            + ":"
            + tvh_port
            + "/comet/poll?boxid="
            + comet_poll_box_id
            + "&immediate=0"
        )
        comet_poll = requests.get(comet_poll_url).json()
        comet_poll_logtxt_list = []
        for t in comet_poll["messages"]:
            comet_poll_logtxt_list.insert(0, t.get("logtxt", "..."))
        comet_poll_logtxt = "\n".join(comet_poll_logtxt_list)
        pDialog.update(10, comet_poll_logtxt)
        time.sleep(1)
        if pDialog.iscanceled():
            pDialog.close()
        comet_update = False
        grabber_success = False
        perc_update = 10
        while comet_update == False:
            if pDialog.iscanceled():
                pDialog.close()
            perc_update = perc_update + int((100 - perc_update) * 0.1) + 1
            comet_poll_logtxt_list = []
            for t in comet_poll["messages"]:
                comet_poll_logtxt_list.insert(0, t.get("logtxt", "..."))
                comet_poll_logtxt = "\n".join(comet_poll_logtxt_list)
            if "grab took" in comet_poll_logtxt:
                comet_update = True
                grabber_success = True
            if "grab returned no data" in comet_poll_logtxt:
                comet_update = True
            pDialog.update(perc_update, comet_poll_logtxt)
            comet_poll = requests.get(comet_poll_url).json()
            time.sleep(1)
        pDialog.update(100, comet_poll_logtxt)
        time.sleep(2)
        pDialog.close()
        if grabber_success == True:
            if dialog.yesno(
                "EPG atualizado",
                "EPG foi atualizado.\nDeseja reiniciar o kodi para efetuar mudanças?",
            ):
                process = subprocess.Popen(
                    "systemctl restart kodi", shell=True, close_fds=True
                )
                process.wait()

        else:
            dialog.ok(
                "Erro ao atualizar epg!",
                "Por favor, verifique as configurações do epg.",
            )


@plugin.route("/map_epg")
def map_epg():
    epggrab_url = f"http://{tvh_url}:{tvh_port}/api/epggrab/channel/grid"
    resp = requests.post(
        epggrab_url,
        data={"sort": "id", "dir": "ASC", "all": "1", "start": 0, "limit": 999999999},
    ).json()

    map_epg = {}

    for epg in resp["entries"]:
        epg["channels"] = []
        map_epg[epg["id"].strip()] = epg

    sel = dialog.select(
        "Selecionar mapa de canais: ", list=["EPGTV - SP", "EPGTV - RJ"]
    )

    url = "https://raw.githubusercontent.com/epgtv/epgtv/master/"

    if sel >= 0:
        if sel == 0:
            url += "channels_sp.json"
        else:
            url += "channels_rj.json"

        map_chan_id = requests.get(url).json()

        channels = list_channels()
        for ch in channels["entries"]:
            epg_id = map_chan_id.get(ch["name"].strip().lower(), None)
            if epg_id:
                epg = map_epg.get(epg_id, None)
                if epg:
                    epg["channels"].append(ch["uuid"])

        save_node_url = f"http://{tvh_url}:{tvh_port}/api/idnode/save"
        nodes = []

        for _id, epg in map_epg.items():
            nodes.append({"uuid": epg["uuid"], "channels": epg["channels"]})

        requests.post(save_node_url, data={"node": json.dumps(nodes)})

        run_epg_grabber()


@plugin.route("/set_epg_source")
def set_epg_source():
    epg_sources = [
        {
            "id": "epgtv",
            "url": "https://github.com/epgtv/epgtv/raw/master/guide.xml.gz",
        },
    ]

    tvheadend = xbmcaddon.Addon("service.tvheadend43")

    type = tvheadend.getSetting("XMLTV_TYPE")
    if type == "WEB":
        value = tvheadend.getSetting("XMLTV_LOCATION_WEB")
    elif type == "NONE":
        value = "desativado"
    elif type == "SCRIPT":
        value = tvheadend.getSetting("XMLTV_LOCATION_SCRIPT")
    else:
        value = tvheadend.getSetting("XMLTV_LOCATION_FILE")

    list_sources = [f"{x['id']}: {x['url']}" for x in epg_sources]

    if type == "WEB":
        selected_source = next(
            (i for i, x in enumerate(epg_sources) if x["url"] == value), -1
        )
    else:
        selected_source = -1

    sel = dialog.select(
        "Selecionar fonte epg: ", list_sources, preselect=selected_source
    )

    if sel >= 0:
        source = epg_sources[sel]
        tvheadend.setSetting(id="XMLTV_TYPE", value="WEB")
        tvheadend.setSetting(id="XMLTV_LOCATION_WEB", value=source["url"])
        if dialog.yesno("Baixar epg", "Deseja baixar o epg?"):
            run_epg_grabber()


@plugin.route("/")
def index():
    items = []
    items.append(
        {
            "label": "Aplicar picons aos canais (by josemoraes99)",
            "path": plugin.url_for("picons"),
            "thumbnail": get_icon_path("adapter"),
        }
    )
    items.append(
        {
            "label": "Busca de canais",
            "path": plugin.url_for("conf_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Busca de canais por frequência",
            "path": plugin.url_for("mux_scan_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    # items.append(
    #     {
    #         "label": "Busca de canais nas frequências",
    #         "path": plugin.url_for("mux_scan"),
    #         "thumbnail": get_icon_path("frequency"),
    #     }
    # )
    items.append(
        {
            "label": "Apagar todos canais",
            "path": plugin.url_for("reset_channels"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Apagar canais por frequência",
            "path": plugin.url_for("reset_channels_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Mapear serviços para acesso do kodi",
            "path": plugin.url_for("map_all_services"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Escolher EPG fonte",
            "path": plugin.url_for("set_epg_source"),
            "thumbnail": get_icon_path("list"),
        }
    )
    items.append(
        {
            "label": "Recarregar EPG",
            "path": plugin.url_for("run_epg_grabber"),
            "thumbnail": get_icon_path("list"),
        }
    )
    items.append(
        {
            "label": "Mapear canais com respectivo EPG id",
            "path": plugin.url_for("map_epg"),
            "thumbnail": get_icon_path("list"),
        }
    )
    return items


if __name__ == "__main__":
    plugin.run()
