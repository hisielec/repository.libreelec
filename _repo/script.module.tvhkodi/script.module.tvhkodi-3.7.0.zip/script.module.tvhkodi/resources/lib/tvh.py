import json
import re
import requests
import unicodedata
import uuid
import os

import sys

if sys.version_info >= (3, 11):
    from typing import Self
else:
    from typing_extensions import Self


PEND = 1
ACTIVE = 3

SDTV = 0x1
SDTV_2 = 0x80
HDTV = 0x19
HDTV_2 = 0x11
UHDTV = 0x1F


any_word = re.compile(r"\W")


class TVH:
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 9981,
        user: str = "",
        password: str = "",
    ) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        if self.user and self.password:
            self.tvh_url = f"http://{self.user}:{self.password}@{self.host}:{self.port}"
        else:
            self.tvh_url = f"http://{self.host}:{self.port}"

    def is_playeable_service(self: Self, service_type: int) -> bool:
        return service_type in [SDTV, SDTV_2, HDTV, HDTV_2, UHDTV]

    def map_all_services(self: Self) -> None:
        u = f"{self.tvh_url}/api/service/mapper/save"
        services = self.get_all_services()
        ids = [service["uuid"] for service in services]
        node = {
            "services": ids,
            "encrypted": True,
            "merge_same_name": False,
            "merge_same_name_fuzzy": False,
            "tidy_channel_name": False,
            "check_availability": False,
            "type_tags": True,
            "provider_tags": False,
            "network_tags": False,
        }
        data = {"node": json.dumps(node)}

        requests.post(u, data=data)

    # retorna todos os canais
    def get_all_channels(self: Self) -> list[dict]:
        u = f"{self.tvh_url}/api/channel/grid"
        data = {
            "start": 0,
            "limit": 999999999,
            "sort": "services",
            "dir": "ASC",
            "all": 1,
        }

        return requests.post(u, data=data).json()["entries"]

    def get_all_muxes(self: Self) -> list[dict]:
        u = f"{self.tvh_url}/api/mpegts/mux/grid"
        data = {
            "sort": "name",
            "dir": "ASC",
        }

        return requests.post(u, data=data).json()["entries"]

    # retorna todos os serviços
    def get_all_services(self: Self) -> list[dict]:
        u = f"{self.tvh_url}/api/mpegts/service/grid"
        data = {
            "start": 0,
            "limit": 999999999,
            "sort": "multiplex",
            "dir": "ASC",
        }

        return requests.post(u, data=data).json()["entries"]

    def get_all_playeable_services(self: Self) -> list[dict]:
        services = []
        for service in self.get_all_services():
            if self.is_playeable_service(service["dvb_servicetype"]):
                services.append(service)

        return services

    def get_muxes_with_no_mapped_services(self: Self) -> list[str]:
        muxes = set()
        for service in self.get_all_services():
            if self.is_playeable_service(service["dvb_servicetype"]):
                name = service["svcname"]
                mux = service["multiplex"]
                channel = service["channel"]
                print(
                    f"name={name} mux={mux} ch={channel[0] if len(channel) > 0 else ''}"
                )
                if len(channel) == 0:
                    muxes.add(service["multiplex_uuid"])

        return list(muxes)

    # deleta nós com determinados uuid
    def delete_nodes(self: Self, uuid: list[str] | str) -> dict:
        if isinstance(uuid, str):
            uuid = [uuid]
        u = f"{self.tvh_url}/api/idnode/delete"
        data = {"uuid": json.dumps(uuid)}

        return requests.post(u, data=data).json()

    def get_all_networks(self: Self) -> dict:
        u = f"{self.tvh_url}/api/mpegts/network/grid"
        data = {
            "sort": "networkname",
            "dir": "ASC",
            "groupBy": False,
            "groupDir": "ASC",
        }

        return requests.post(u, data=data).json()["entries"]

    def get_network_by_uuid(self: Self, uuid: str) -> dict:
        networks = self.get_all_networks()

        for network in networks:
            if network["uuid"] == uuid:
                return network

        return {}

    def get_dvbc_adapters(self: Self) -> list[dict]:
        u = f"{self.tvh_url}/api/hardware/tree"
        data = {
            "uuid": "root",
        }

        adapters = requests.post(u, data=data).json()
        dvb_adapters = []
        for adapter in adapters:
            if "DVB-C" in adapter["text"]:
                current_adapter = self.get_adapter(adapter_uuid=adapter["id"])
                if current_adapter == None:
                    continue
                current_adapter["opt"] = {}
                for param in current_adapter["params"]:
                    if param["value"]:
                        current_adapter["opt"][param["id"]] = param["value"]

                dvb_adapters.append(current_adapter)

        return dvb_adapters

    def get_adapter(self: Self, adapter_uuid: str) -> dict | None:
        u = f"{self.tvh_url}/api/hardware/tree"
        data = {
            "uuid": adapter_uuid,
        }

        adapter = requests.post(u, data=data).json()

        if adapter:
            return adapter[0]

        return None

    def get_network_from_adapter(self: Self, adapter_uuid: str) -> str:
        adapter = self.get_adapter(adapter_uuid=adapter_uuid)
        if not adapter:
            return ""

        for param in adapter["params"]:
            if param["id"] == "networks":
                return param["value"][0]

        return ""

    def new_dvbc_network(self: Self, name: str) -> None:
        u = f"{self.tvh_url}/api/mpegts/network/create"

        conf = {
            "networkname": name,
            "scanfile": "",
            "pnetworkname": "",
            "nid": 0,
            "autodiscovery": 1,
            "ignore_chnum": "false",
            "satip_source": 0,
            "charset": "ISO-8859-1",
            "skipinitscan": "true",
            "idlescan": "false",
            "sid_chnum": "false",
            "localtime": 0,
        }

        data = {
            "class": "dvb_network_dvbc",
            "conf": json.dumps(conf),
        }

        return requests.post(u, data=data).json()["uuid"]

    # adiciona mux e retorna uuid do mux
    def add_mux(self: Self, network_uuid: str, frequency_in_MHz: int) -> str:
        u = f"{self.tvh_url}/api/mpegts/network/mux_create"
        data = {
            "uuid": network_uuid,
            "conf": json.dumps(
                {
                    "enabled": 1,
                    "epg": 1,
                    "epg_module_id": "eit",
                    "delsys": "DVB-C",
                    "frequency": frequency_in_MHz * 1_000_000,
                    "symbolrate": "5217000",
                    "constellation": "QAM/256",
                    "fec": "AUTO",
                    "plp_id": -1,
                    "scan_state": 0,
                    "charset": "ISO-8859-1",
                    "tsid_zero": "false",
                    "pmt_06_ac3": 0,
                    "eit_tsid_nocheck": "false",
                    "sid_filter": 0,
                    "data_slice": 0,
                }
            ),
        }

        resp = requests.post(u, data=data).json()

        return resp["uuid"]

    def get_node(self: Self, uuid: str) -> dict:
        u = f"{self.tvh_url}/api/idnode/load"
        data = {
            "uuid": uuid,
            "meta": 1,
        }

        entry = requests.post(u, data).json()["entries"][0]

        node = {
            "uuid": entry["uuid"],
        }

        for param in entry["params"]:
            if "value" in param:
                node[param["id"]] = param["value"]

        if "class" in entry:
            node["class"] = entry["class"]

        return node

    def scan(self: Self, muxes_uuid: list[str]) -> None:
        u = f"{self.tvh_url}/api/idnode/save"
        for uuid in muxes_uuid:
            node = self.get_node(uuid)
            node["scan_state"] = ACTIVE
            data = {"node": json.dumps(node)}
            requests.post(u, data=data)

    def delete_all_networks(self: Self) -> None:
        ids = []
        for network in self.get_all_networks():
            ids.append(network["uuid"])

        if len(ids) > 0:
            self.delete_nodes(ids)

    def delete_all_muxes(self: Self) -> None:
        ids = []
        for mux in self.get_all_muxes():
            ids.append(mux["uuid"])

        if len(ids) > 0:
            self.delete_nodes(ids)

    def delete_all_services(self: Self) -> None:
        ids = []
        for service in self.get_all_services():
            ids.append(service["uuid"])

        if len(ids) > 0:
            self.delete_nodes(ids)

    def delete_all_channels(self: Self) -> None:
        ids = []
        for channel in self.get_all_channels():
            ids.append(channel["uuid"])

        if len(ids) > 0:
            self.delete_nodes(ids)

    def reset_tv(self: Self) -> None:
        self.delete_all_channels()
        self.delete_all_services()
        self.delete_all_muxes()

    def clean_name(self: Self, ch) -> str:
        return re.sub(
            any_word,
            "",
            "".join(
                c.lower()
                for c in unicodedata.normalize("NFKD", ch.replace("+", "mais"))
                .encode("ascii", "ignore")
                .decode("ascii")
                if not c.isspace()
            ),
        )

    def parse_config(self: Self, data: str) -> dict:
        sid_name_to_id = {}
        for line in data.split("\n"):
            l = line.strip()
            if not l or l.startswith("#"):
                continue
            splitted_line = l.split("=")
            if not splitted_line or len(splitted_line) < 2:
                continue

            id = splitted_line[0]
            for channel_name in splitted_line[1].split(","):
                stripped_channel_name = channel_name.strip()
                if stripped_channel_name:
                    sid_name_to_id[stripped_channel_name.lower()] = id

        return sid_name_to_id

    def set_picons(self: Self) -> None:
        u = "https://hk319yfwbl.execute-api.sa-east-1.amazonaws.com/prod"  # by josemoraes99
        names = set()
        channels = self.get_all_channels()
        for channel in channels:
            names.add(self.clean_name(channel["name"]))

        payload = {"src": "kodi", "node": uuid.getnode(), "listChannel": list(names)}
        headers = {"content-type": "application/json"}

        resp = requests.post(u, data=json.dumps(payload), headers=headers).json()

        map_picons = {name: url for name, url in resp["listaPicons"]}

        prefix_picons_url = "https://raw.githubusercontent.com/HisiELEC/picons/main"
        map_picons_url = prefix_picons_url + "/picon.map"
        map_picons_root = self.parse_config(requests.get(map_picons_url).text)

        nodes = []
        for channel in channels:
            name = channel["name"]
            value = map_picons_root.get(name.lower())
            if value is not None:
                if value.startswith("http"):
                    url = value
                else:
                    url = prefix_picons_url + "/img/" + value
            else:
                url = map_picons.get(self.clean_name(name))

            if url:
                print(f"name = {name} | url = {url}")
                nodes.append({"icon": url, "uuid": channel["uuid"]})

        if len(nodes) > 0:
            u = f"{self.tvh_url}/api/idnode/save"
            requests.post(u, data={"node": json.dumps(nodes)})

    def enable_mux_eit(self: Self, muxes_uuid: list[str]) -> None:
        u = f"{self.tvh_url}/api/idnode/save"
        node = {
            "epg_module_id": "eit",
            "uuid": muxes_uuid,
        }
        data = {"node": json.dumps(node)}
        requests.post(u, data=data)

    def toggle_eit(self: Self, enable: bool) -> bool:
        eit_entry = None
        for entry in self.get_all_epg_modules():
            if "EIT" in entry["title"]:
                eit_entry = entry
                break

        if eit_entry:
            node = {
                "priority": 1,
                "short_target": 0,
                "running_immediate": False,
                "scrape_config": "",
                "scrape_episode": False,
                "scrape_title": False,
                "scrape_subtitle": False,
                "scrape_summary": False,
                "uuid": eit_entry["uuid"],
            }

            if enable and not "Enable" in eit_entry["status"]:
                node["enabled"] = True
            elif not enable and "Enable" in eit_entry["status"]:
                node["enabled"] = False

            if "enabled" in node:
                u = f"{self.tvh_url}/api/idnode/save"
                requests.post(u, data={"node": json.dumps(node)})
                return True

        return False

    def get_all_epg_modules(self: Self) -> dict:
        u = f"{self.tvh_url}/api/epggrab/module/list"
        return requests.get(u).json()["entries"]

    def refresh_grabbers(self: Self) -> None:
        u = f"{self.tvh_url}/api/epggrab/internal/rerun"
        data = {
            "rerun": "1",
        }
        requests.post(u, data=data)

    def toggle_xml_epg(self: Self, enable: bool) -> bool:
        xml_entry = None
        for entry in self.get_all_epg_modules():
            if "Internal: XML" in entry["title"]:
                xml_entry = entry
                break

        if xml_entry:
            node = {
                "priority": 3,
                "args": "",
                "dn_chnum": 0,
                "scrape_extra": True,
                "scrape_onto_desc": False,
                "use_category_not_genre": False,
                "uuid": xml_entry["uuid"],
            }
            if enable and not "Enable" in xml_entry["status"]:
                node["enabled"] = True
            elif not enable and "Enable" in xml_entry["status"]:
                node["enabled"] = False

            if "enabled" in node:
                u = f"{self.tvh_url}/api/idnode/save"
                requests.post(u, data={"node": json.dumps(node)})
                return True

        return False

    def update_xml_epg_url(self: Self, path: str, xml_url: str) -> None:
        settings = os.path.join(path, "settings.xml")
        lines = []
        with open(settings, "r", encoding="utf-8") as f:
            for line in f.readlines():
                if "XMLTV_TYPE" in line:
                    line = '    <setting id="XMLTV_TYPE">WEB</setting>\n'
                elif "XMLTV_LOCATION_WEB" in line:
                    line = f'    <setting id="XMLTV_LOCATION_WEB">{xml_url}</setting>\n'
                lines.append(line)

        with open(settings, "w", encoding="utf-8") as f:
            for line in lines:
                f.write(line)

    def get_all_epggrab_channels(self: Self) -> dict:
        u = f"{self.tvh_url}/api/epggrab/channel/grid"
        data = {"sort": "id", "dir": "ASC", "all": "1", "start": 0, "limit": 999999999}

        return requests.post(u, data=data).json()["entries"]

    def map_epg_channel(self: Self, map_url: str) -> None:
        data = requests.get(map_url).text
        name_to_epg_id = self.parse_config(data)
        epg_by_id = {}
        for entry in self.get_all_epggrab_channels():
            epg_by_id[entry["id"]] = entry

        epg_changed = {}
        for channel in self.get_all_channels():
            name = channel["name"].lower()
            epg_id = name_to_epg_id.get(name)
            epg_entry = epg_by_id.get(epg_id)
            if epg_entry:
                uuid = epg_entry.get("uuid")
                if not epg_changed.get(uuid):
                    epg_changed[uuid] = set()
                    epg_changed[uuid].update(epg_entry.get("channels"))
                epg_changed[uuid].add(channel["uuid"])

        nodes = []
        for uuid in epg_changed:
            node = {
                "uuid": uuid,
                "channels": list(epg_changed[uuid]),
            }
            nodes.append(node)

        if len(nodes) > 0:
            u = f"{self.tvh_url}/api/idnode/save"
            data = {"node": json.dumps(nodes)}
            requests.post(u, data=data)

    def delete_all_epg_grabber_channels(self: Self) -> None:
        uuid = []
        for channel in self.get_all_epggrab_channels():
            uuid.append(channel["uuid"])

        if len(uuid) > 0:
            self.delete_nodes(uuid)

    def get_services_by_mux(
        self: Self, mux_uuid: str, sort_by_sid: bool = True
    ) -> list[dict]:
        services = list(
            filter(
                lambda svc: svc["multiplex_uuid"] == mux_uuid,
                self.get_all_services(),
            )
        )

        if sort_by_sid:
            services.sort(key=lambda svc: svc["sid"])

        return services

    def poll_id(self: Self) -> int:
        u = f"{self.tvh_url}/comet/poll"
        poll = requests.get(u).json()
        return poll["boxid"]

    def get_messages(self: Self, id: int) -> dict:
        u = f"{self.tvh_url}/comet/poll?boxid={id}&immediate=1"
        return requests.get(u).json()["messages"]

    def get_map_status(self: Self) -> dict:
        u = f"{self.tvh_url}/api/service/mapper/status"
        return requests.get(u).json()

    def get_input_status(self: Self) -> list[dict]:
        u = f"{self.tvh_url}/api/status/inputs"
        return requests.get(u).json()["entries"]

    def change_node_info(self: Self, node: dict) -> None:
        u = f"{self.tvh_url}/api/idnode/save"
        data = {"node": json.dumps(node)}
        requests.post(u, data=data)

    def epggrab_load(self: Self) -> dict:
        u = f"{self.tvh_url}/api/epggrab/config/load"
        grab = requests.get(u).json().get("entries")[0]
        grab["opt"] = {}
        for param in grab["params"]:
            if "value" in param:
                grab["opt"][param["id"]] = param["value"]

        return grab

    def epggrab_save(self: Self, node: dict) -> None:
        u = f"{self.tvh_url}/api/epggrab/config/save"
        data = {"node": json.dumps(node)}
        requests.post(u, data=data).json()


if __name__ == "__main__":
    # map_all_services()
    # uuid = add_mux("4e8ff85cd5745ae676e665bf203fa0d5", 573)
    # print(uuid)
    tvh = TVH("192.168.1.76")
    channels = tvh.get_all_playeable_services()
    # channels.sort(key=lambda ch: ch["sid"])
    # channels.sort(key=lambda ch: int(ch["multiplex"][:3]))

    for ch in channels:
        print(ch["svcname"] + " " + str(ch["sid"]) + " " + ch["multiplex"])

    # print(tvh.get_muxes_with_no_mapped_services())

    # muxes = tvh.get_all_muxes()
    # for mux in muxes:
    #     print(f" uuid = {mux['uuid']} name = {mux['name']}")

    # tvh.scan(["569dfa318aadfc3df62972736c5ad1ec", "ddbd7de3d01b694f216b08c7e78504c1"])
    # print(json.dumps(channels,indent=2))

    # print(tvh.get_dvb_adapters())

    # tvh.map_epg_channel("https://raw.githubusercontent.com/HisiELEC/epg/main/rootcoder/channels_rj.map")

    # adapters = tvh.get_dvb_adapters()
    # network_uuid = tvh.get_network_from_adapter(adapters[0]["uuid"])
    # print(network_uuid)

    # muxes = tvh.get_muxes_with_no_mapped_services()
    # print("mux", list(muxes))
    # set_picons()
    # mux_135 = list(
    #     filter(
    #         lambda svc: svc["multiplex_uuid"] == "c8904462c6c154effa8782e5aa06add0",
    #         get_all_services(),
    #     )
    # )
    # mux_135 = tvh.get_services_by_mux("c8904462c6c154effa8782e5aa06add0")
    # for svc in mux_135:
    #     print(f"name = {svc['svcname']} | sid = {svc['sid']}")
    # muxes = tvh.get_all_muxes()
    # for mux in muxes:
    #     print(f" uuid = {mux['uuid']} name = {mux['name']}")

    # set_picons()
    # delete_all_epg_grabber_channels()
    # refresh_grabbers()
    # time.sleep(10)
    # delete_all_epg_grabber_channels()
    # map_epg_channel(
    # "https://raw.githubusercontent.com/HisiELEC/epg/main/rootcoder/channels_sp.map"
    # )
    # p_id = poll_id()
    # refresh_grabbers()
    # i = 0
    # while True:

    #     for message in get_messages(p_id):
    #         # print(json.dumps(message, indent=2))
    #         if message.get("notificationClass") == "logmessage":
    #             text = message.get("logtxt")
    #             if "grab took" in text or "parse took" in text or "no output" in text:
    #                 print(json.dumps(message, indent=2))
    #     time.sleep(1)
    #     i += 1

    #     if i == 30:
    #         break
    # tvh.reset_tv()
    # time.sleep(10)
    # refresh_grabbers()
    # print(toggle_eit(True))
    # update_xml_epg_url(
    #     "/storage/.kodi/userdata/addon_data/service.tvheadend43/",
    #     "https://github.com/rootcoder/epgtv/raw/main/guide2.xml.gz",
    # )
    # scan(["e3ad518fbeeec23549540bfcc48f4654"])
    # nodes = get_node(ids)
    # print(json.dumps(nodes, indent=2))
    # delete_all_muxes()
