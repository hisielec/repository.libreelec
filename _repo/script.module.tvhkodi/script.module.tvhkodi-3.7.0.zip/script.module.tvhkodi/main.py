import xbmcaddon
import xbmc
import xbmcvfs
import xbmcgui
import xbmcplugin
import subprocess
import re
import requests

from typing import Callable
from resources.lib.tvh import TVH
from resources.lib.router import Router

# from resources.lib.oscam_dialog import OscamDialog

plugin = Router()
conf_addon_tvh = xbmcaddon.Addon("service.tvheadend43")
path_tvheadend43 = xbmcvfs.translatePath(conf_addon_tvh.getAddonInfo("profile"))

try:
    host = xbmcaddon.Addon("pvr.hts").getSetting("host")
    if host:
        xbmcaddon.Addon().setSetting(id="tvhurl", value=host)
    else:
        try:
            host = xbmcaddon.Addon().getSetting("tvhurl")
        except:
            xbmcaddon.Addon().setSetting(id="tvhurl", value="127.0.0.1")
    port = xbmcaddon.Addon("pvr.hts").getSetting("http_port")
    if port:
        xbmcaddon.Addon().setSetting(id="tvhport", value=port)
    else:
        try:
            port = xbmcaddon.Addon().getSetting("tvhport")
        except:
            xbmcaddon.Addon().setSetting(id="tvhport", value="9981")
except:
    pass

port = xbmcaddon.Addon().getSetting("tvhport")
user = xbmcaddon.Addon().getSetting("usern")
password = xbmcaddon.Addon().getSetting("passw")

tvh = TVH(host, int(port), user, password)


def map_services() -> None:
    tvh.map_all_services()


def scan_channels_progress(network_uuid: str) -> None:
    monitor = xbmc.Monitor()
    dialog = xbmcgui.Dialog()
    network = tvh.get_network_by_uuid(network_uuid)
    progress = xbmcgui.DialogProgress()
    progress.create("Buscando canais...", "Aguarde...")
    num_services_found = 0
    if not monitor.waitForAbort(1):
        num_services_before = network["num_svc"]
        num_scan_muxes = float(network["scanq_length"])
        rgx = re.compile(r"(\d+MHz)")

        while network["scanq_length"] != 0 and not monitor.waitForAbort(1):
            network = tvh.get_network_by_uuid(network_uuid)
            num_services_found = network["num_svc"] - num_services_before
            percent = int(100 - (network["scanq_length"] / num_scan_muxes) * 100)
            input_status = []
            for status in tvh.get_input_status():
                stream = status.get("stream")
                if stream:
                    match = rgx.search(stream)
                    if match:
                        input_status.append(match.group(1))
            search_muxes_msg = " & ".join(input_status)
            msg = f"Buscando: {search_muxes_msg}\nNovos serviços encontrados: {num_services_found}"
            progress.update(percent, msg)
            if progress.iscanceled():
                dialog.ok("Busca cancelada", "Novos serviços não serão mapeados.")
                return

    progress.close()

    dialog.notification(
        "Busca de canais", "Mapeando canais...", xbmcgui.NOTIFICATION_INFO, 4000
    )

    tvh.map_all_services()

    if monitor.waitForAbort(5):
        return

    mapped = tvh.get_map_status()

    msg = f"Novos serviços encontrados: {num_services_found}\nCanais mapeados: {mapped['ok']}.\n"

    dialog.ok("Busca completa.", msg)


def get_network() -> str:
    adapters = tvh.get_dvbc_adapters()
    if len(adapters) == 0:
        return ""

    networks = tvh.get_all_networks()
    for network in networks:
        node = tvh.get_node(uuid=network["uuid"])
        if "dvbc" in node["class"]:
            dvbc_uuid_network = network["uuid"]
            break

    if not dvbc_uuid_network:
        dvbc_uuid_network = tvh.new_dvbc_network("Claro TV")

    for adapter in adapters:
        conf = adapter["opt"]
        if conf["active"] == False or not "networks" in conf:
            node = {"uuid": adapter["uuid"]}

            for key in conf:
                node[key] = conf[key]

            node["enabled"] = True
            node["networks"] = [dvbc_uuid_network]

            tvh.change_node_info(node)

    if not dvbc_uuid_network:
        return ""

    return dvbc_uuid_network


@plugin.route("/scan_channels")
def scan_channels() -> None:
    dialog = xbmcgui.Dialog()
    dialog.notification(
        "Busca de canais", "Verificando informações...", xbmcgui.NOTIFICATION_INFO, 1000
    )

    network_uuid = get_network()
    if network_uuid == "":
        dialog.ok(
            "Tuner não configurado!",
            "Por favor, verifique configurações dos tuners.",
        )
        return

    frequency = dialog.input("Frequência em MHz: (Ex: 567)", type=xbmcgui.INPUT_NUMERIC)
    if frequency:
        frequency = int(frequency)
        if frequency >= 111 and frequency <= 783:
            monitor = xbmc.Monitor()
            dialog.notification(
                "Busca de canais",
                "Apagando canais. Aguarde...",
                xbmcgui.NOTIFICATION_INFO,
                6000,
            )
            tvh.reset_tv()  # apagar canais / muxes / serviços
            if monitor.waitForAbort(4):
                return
            dialog.notification(
                "Busca de canais", "Iniciando busca...", xbmcgui.NOTIFICATION_INFO, 3000
            )
            tvh.add_mux(network_uuid=network_uuid, frequency_in_MHz=frequency)
            scan_channels_progress(network_uuid=network_uuid)
        else:
            dialog.ok("Erro ao buscar canais", "Frequência deve estar entre 111 e 783")


@plugin.route("/picon")
def picon() -> None:
    dialog = xbmcgui.Dialog()
    dialog.notification(
        "Picons", "Atualizando picons...", xbmcgui.NOTIFICATION_INFO, 6000
    )

    tvh.set_picons()
    if dialog.yesno(
        "Picons atualizados!", "Deseja reiniciar kodi para efetuar as mudanças?"
    ):
        subprocess.run(
            ["systemctl", "restart", "--no-block", "kodi"],
            capture_output=True,
            text=True,
        )


def toggle_update_channel_name(update: bool) -> None:
    grab = tvh.epggrab_load()
    if grab["opt"]["channel_rename"] != update:
        tvh.epggrab_save(grab["opt"])


def get_epg_sources() -> dict:
    u = "https://raw.githubusercontent.com/HisiELEC/epg/main/epg.json"
    return requests.get(u).json()


def select_epg_mapper() -> dict | None:
    dialog = xbmcgui.Dialog()
    epg_sources = get_epg_sources()
    xmltv_type = conf_addon_tvh.getSetting("XMLTV_TYPE")
    current_xml_url = ""
    if xmltv_type == "WEB":
        current_xml_url = conf_addon_tvh.getSetting("XMLTV_LOCATION_WEB")
    else:
        conf_addon_tvh.setSetting("XMLTV_TYPE", "WEB")

    select_idx = -1
    options = []
    for i, source in enumerate(epg_sources):
        if source["url"] == current_xml_url:
            select_idx = i
        options.append(f"{source['id']}: {source['url']}")

    selected_source = dialog.select(
        "Selecionar fonte para EPG [Guia de Programação]: ",
        options,
        preselect=select_idx,
    )

    if selected_source != -1:
        return epg_sources[selected_source]

    return None


def reload_epg(title: str) -> bool:
    tvh.refresh_grabbers()
    progress = xbmcgui.DialogProgress()
    progress.create(title, "Aguarde...")
    monitor = xbmc.Monitor()
    i = 0
    stop = False
    p_id = tvh.poll_id()
    while True:
        for message in tvh.get_messages(p_id):
            if message.get("notificationClass") == "logmessage":
                text = message.get("logtxt")
                if "grab took" in text:
                    progress.update(50, f"Progresso: 50%!")
                elif "parse took" in text:
                    progress.update(100, "Progresso: 100%\nBaixado com sucesso!")
                    if monitor.waitForAbort(2):
                        stop = True
                        break
                    progress.close()
                    return True
                elif "no output detected" in text or "grab returned no data" in text:
                    stop = True
                    break

        i += 1
        if i == 50 or stop:
            break
        if monitor.waitForAbort(1):
            break
    xbmc.log("Abortando...", xbmc.LOGINFO)
    progress.close()

    return False


@plugin.route("/config_epg")
def config_epg() -> None:
    dialog = xbmcgui.Dialog()
    toggle_update_channel_name(False)
    if dialog.yesno("Guia de Programação (EPG)", "Deseja apagar mapeamento anterior?"):
        uuids = [grab["uuid"] for grab in tvh.get_all_epggrab_channels()]
        tvh.delete_nodes(uuids)

    epg_source = select_epg_mapper()
    if epg_source:
        tvh.update_xml_epg_url(path_tvheadend43, epg_source["channelUrl"])

        dialog.notification(
            "Guia",
            "Iniciando download do guia. Aguarde...",
            xbmcgui.NOTIFICATION_INFO,
            4000,
        )
        if not reload_epg("Etapa 1: Baixando IDs para mapeamento"):
            tvh.update_xml_epg_url(path_tvheadend43, epg_source["url"])
            dialog.ok("Falha", "Falha ao baixar IDs")
            return

        tvh.update_xml_epg_url(path_tvheadend43, epg_source["url"])

        map_url = ""
        if isinstance(epg_source["map"], list):
            options = [m["id"] for m in epg_source["map"]]
            idx = dialog.select("Selecionar cidade: ", options)
            if idx != -1:
                map_url = epg_source["map"][idx]["url"]
        else:
            map_url = epg_source["map"]

        if map_url:
            tvh.map_epg_channel(map_url)
            if not reload_epg("Etapa 2: Baixando Guia de Programação"):
                dialog.ok("Falha", "Falha ao baixar guia")
                return

            dialog.ok("Guia de Programação", "Baixado e mapeado!!")


@plugin.route("/show_list_ch")
def show_list_ch(by: str) -> None:
    services = tvh.get_all_playeable_services()
    services.sort(key=lambda ch: ch["sid"])

    if by == "mux":
        services.sort(key=lambda ch: int(ch["multiplex"][:3]))  # stable sort

    def add_line(text: str) -> None:
        li = xbmcgui.ListItem(text)
        xbmcplugin.addDirectoryItem(
            handle=plugin.handle, url="", listitem=li, isFolder=False
        )

    cur_mux = ""
    if by == "mux":
        for svc in services:
            if cur_mux == "" or cur_mux != svc["multiplex"]:
                cur_mux = svc["multiplex"]
                mux = f"[B][COLOR yellow][{cur_mux}][/COLOR][/B]"
                add_line(mux)
            mapped = (
                " - [B][COLOR pink][Mapeado][/COLOR][/B]"
                if len(svc["channel"]) > 0
                else ""
            )
            line = f"{svc['sid']} - {svc['svcname']}{mapped}"
            add_line(line)
    elif by == "sid":
        for svc in services:
            mapped = (
                " - [B][COLOR pink][Mapeado][/COLOR][/B]"
                if len(svc["channel"]) > 0
                else ""
            )
            line = f"{svc['sid']} - {svc['svcname']}{mapped} [B][COLOR yellow][{svc['multiplex']}][/B][/COLOR]"
            add_line(line)

    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/show_list_ch_nmap")
def show_list_ch_nmap():
    muxes_uuid = tvh.get_muxes_with_no_mapped_services()
    if len(muxes_uuid) > 0:
        mux_list = []
        for mux in tvh.get_all_muxes():
            if mux["uuid"] in muxes_uuid:
                mux_list.append(mux)

        if len(mux_list) > 0:
            tvh.delete_nodes(muxes_uuid)
            for mux in mux_list:
                tvh.add_mux(
                    network_uuid=mux["network_uuid"],
                    frequency_in_MHz=int(mux["name"][:3]),
                )
            scan_channels_progress(mux_list[0]["network_uuid"])
    xbmcplugin.endOfDirectory(plugin.handle)


def add_item(
    name: str, func: Callable | None = None, is_group: bool = False, options: dict = {}
) -> None:
    item = xbmcgui.ListItem(name)
    u = ""
    if func:
        u = plugin.url_for(func, **options)
    xbmcplugin.addDirectoryItem(
        handle=plugin.handle,
        listitem=item,
        isFolder=is_group,
        url=u,
    )


@plugin.route("/list_ch")
def list_ch() -> None:
    add_item(
        "Lista de Canais por Frequência",
        show_list_ch,
        is_group=True,
        options={"by": "mux"},
    )
    add_item(
        "Lista de Canais por Número", show_list_ch, is_group=True, options={"by": "sid"}
    )
    add_item("Lista de Canais Não Mapeados", show_list_ch_nmap, is_group=True)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route("/scan_mux_uuid")
def scan_mux_uuid(uuid: str, network_uuid: str) -> None:
    dialog = xbmcgui.Dialog()
    dialog.notification(
        "Busca de canais por frequência", "Aguarde...", xbmcgui.NOTIFICATION_INFO, 4000
    )
    services = []
    channels = []
    frequency = 0
    for svc in tvh.get_all_services():
        if svc["multiplex_uuid"] == uuid:
            services.append(svc["uuid"])
            channels.extend(svc["channel"])
            frequency = int(svc["multiplex"][:3])

    if len(services) > 0:
        tvh.delete_nodes(channels)
        tvh.delete_nodes(services)
        tvh.delete_nodes(uuid)
        tvh.add_mux(network_uuid=network_uuid, frequency_in_MHz=frequency)
        scan_channels_progress(network_uuid=network_uuid)


@plugin.route("/scan_mux")
def scan_mux() -> None:
    for mux in tvh.get_all_muxes():
        li = xbmcgui.ListItem(mux["name"])
        u = plugin.url_for(
            scan_mux_uuid, uuid=mux["uuid"], network_uuid=mux["network_uuid"]
        )
        xbmcplugin.addDirectoryItem(
            handle=plugin.handle, url=u, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(plugin.handle)


# @plugin.route("/open_oscam_conf")
# def open_oscam_conf() -> None:
#     dialog = OscamDialog()
#     dialog.doModal()


@plugin.route("/")
def index() -> None:
    add_item("Aplicar picons", picon)
    add_item("Busca de canais", scan_channels)
    add_item("Busca de canais por frequência", scan_mux, is_group=True)
    add_item("Configurar EPG (Guia de Programação)", config_epg)
    add_item("Lista de Canais", list_ch, is_group=True)
    # add_item("Configurar OsCam", open_oscam_conf)
    add_item(
        "[I][COLOR pink]** outras configurações em construção **[/COLOR][/I]", None
    )
    xbmcplugin.endOfDirectory(plugin.handle)


if __name__ == "__main__":
    xbmcplugin.setContent(plugin.handle, "movies")
    plugin.run()
