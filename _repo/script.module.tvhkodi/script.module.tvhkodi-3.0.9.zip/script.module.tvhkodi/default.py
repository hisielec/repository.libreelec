import xbmc, xbmcaddon, xbmcvfs, xbmcgui, xbmcplugin
from xbmcswift2 import Plugin
import requests
import os
import json
import uuid
import unicodedata
import re
import time
import urllib
import subprocess

plugin = Plugin()
dialog = xbmcgui.Dialog()
ADDON = xbmcaddon.Addon()
try:
    tvh_url_get = xbmcaddon.Addon("pvr.hts").getSetting("host")
    if tvh_url_get:
        xbmcaddon.Addon().setSetting(id="tvhurl", value=tvh_url_get)
    else:
        try:
            tvh_url = xbmcaddon.Addon().getSetting("tvhurl")
        except:
            xbmcaddon.Addon().setSetting(id="tvhurl", value="127.0.0.1")
    tvh_port_get = xbmcaddon.Addon("pvr.hts").getSetting("http_port")
    if tvh_port_get:
        xbmcaddon.Addon().setSetting(id="tvhport", value=tvh_port_get)
    else:
        try:
            tvh_port = xbmcaddon.Addon().getSetting("tvhport")
        except:
            xbmcaddon.Addon().setSetting(id="tvhport", value="9981")
except:
    pass

tvh_port = xbmcaddon.Addon().getSetting("tvhport")
tvh_usern = xbmcaddon.Addon().getSetting("usern")
tvh_passw = xbmcaddon.Addon().getSetting("passw")
if tvh_usern != "" and tvh_passw != "":
    tvh_url = tvh_usern + ":" + tvh_passw + "@" + xbmcaddon.Addon().getSetting("tvhurl")
else:
    tvh_url = xbmcaddon.Addon().getSetting("tvhurl")

try:
    check_url = "http://" + tvh_url + ":" + tvh_port + "/api/status/connections"
    check_load = requests.get(check_url)
    check_status = check_load.raise_for_status()
except requests.exceptions.HTTPError as err:
    dialog.ok(
        "Error",
        f"Tvheadend Access Error!\n{str(err)}\nPlease check your username/password in settings.",
    )
except requests.exceptions.RequestException as e:
    dialog.ok(
        "Error",
        "Tvheadend Access Error!\nCould not connect to Tvheadend server.\nPlease check your Tvheadend server is running or check the IP and port configuration in the settings.",
    )


re_word = re.compile("\W")


def clean_chan_name(ch):
    return re.sub(
        re_word,
        "",
        "".join(
            c.lower()
            for c in unicodedata.normalize("NFKD", ch.replace("+", "mais"))
            .encode("ascii", "ignore")
            .decode("ascii")
            if not c.isspace()
        ),
    )


def get_icon_path(icon_name):
    addon_path = xbmcaddon.Addon().getAddonInfo("path")
    return os.path.join(addon_path, "resources", "img", icon_name + ".png")


@plugin.route("/picons")
def picons():
    # picons by josemoraes99
    # https://github.com/josemoraes99/kodi_picons.git
    url_picon = "https://hk319yfwbl.execute-api.sa-east-1.amazonaws.com/prod"
    channels_url = (
        f"http://{tvh_url}:{tvh_port}/api/channel/grid?all=1&limit=999999999&sort=name"
    )
    channels = requests.get(channels_url).json()
    channel_name = set()

    for ch in channels["entries"]:
        channel_name.add(clean_chan_name(ch["name"]))

    payload = {"src": "kodi", "node": uuid.getnode(), "listChannel": list(channel_name)}
    headers = {"content-type": "application/json"}
    r = requests.post(url_picon, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    map_chan_url = {}
    xbmc.log(json.dumps(resp), xbmc.LOGINFO)
    for picons in resp["listaPicons"]:
        map_chan_url[picons[0]] = picons[1]

    for ch in channels["entries"]:
        name = clean_chan_name(ch["name"])
        url = map_chan_url[name]
        if url:
            param_url = (
                "http://"
                + tvh_url
                + ":"
                + tvh_port
                + '/api/idnode/save?node={"icon":"'
                + url
                + '","uuid":"'
                + ch["uuid"]
                + '"}'
            )
            requests.get(param_url)

    if dialog.yesno(
        "Picons atualizados!", "Deseja reiniciar kodi para efetuar as mudanças?"
    ):
        subprocess.run(
                ["systemctl", "restart", "kodi"],
                capture_output=True,
                text=True,
            )

def load_services():
    services_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/service/grid?start=0&limit=999999999&sort=multiplex"
    services_load = requests.get(services_url).json()

    return services_load


# http://192.168.1.74:9981/api/service/mapper/save


def services_param_load():
    services_url = "http://" + tvh_url + ":" + tvh_port + "/api/service/mapper/load"
    services_load = requests.get(services_url).json()
    services_opt_id = ["", ""]
    services_opt_label = ["", ""]
    services_node = {}
    for param in services_load["entries"][0]["params"]:
        serv_id = param["id"]
        if serv_id != "services":
            services_opt_id.append(serv_id)
            serv_label = param["caption"]
            services_opt_label.append(serv_label)
            serv_value_orig = param["value"]
            services_node[serv_id] = serv_value_orig
    return services_node


@plugin.route("/map_all_services")
def map_all_services():
    services = load_services()
    services_node = services_param_load()
    serv_total = services["total"]
    serv_uuid = []
    for serv_id in services["entries"]:
        if serv_id["channel"] == []:
            serv_uuid.append(serv_id["uuid"])
    serv_uuid_str = str(serv_uuid)
    serv_uuid_str = re.sub("u'", '"', serv_uuid_str)
    serv_uuid_str = re.sub("'", '"', serv_uuid_str)
    serv_node_str = json.dumps(services_node)
    serv_node_str = re.sub("{", "", serv_node_str)
    map_url = (
        "http://"
        + tvh_url
        + ":"
        + tvh_port
        + '/api/service/mapper/save?node={"services":'
        + serv_uuid_str
        + ","
        + serv_node_str
    )
    map_ch = requests.get(map_url)
    status_url = "http://" + tvh_url + ":" + tvh_port + "/api/service/mapper/status"
    time.sleep(3)
    map_status = requests.get(status_url).json()
    map_total_num = map_status["total"]
    map_ok_num = map_status["ok"]
    map_fail_num = map_status["fail"]
    map_ignore_num = map_status["ignore"]
    map_complete = map_ok_num + map_fail_num + map_ignore_num
    map_total_perc = (float(map_complete) / float(serv_total)) * 100
    dialog.ok(
        "Canais mapeados.",
        f"{map_ok_num} novos canais.\n{map_ignore_num} ignorados.",
    )


def scan_network(net_uuid_sel):
    adapters_url = f"http://{tvh_url}:{tvh_port}/api/hardware/tree?uuid=root"
    adapters_get = requests.get(adapters_url).json()
    if adapters_get == []:
        dialog.ok(
            "Tuner não configurado!",
            "Por favor, verifique configurações.",
        )
        return
    scan_url = (
        f"http://{tvh_url}:{tvh_port}/api/mpegts/network/scan?uuid={net_uuid_sel}"
    )
    update_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/grid"
    mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid"
    stream_url = f"http://{tvh_url}:{tvh_port}/api/status/inputs"
    mux_list_get = requests.get(mux_url).json()
    mux_list = [x["uuid"] for x in mux_list_get["entries"]]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("Buscando canais...")
    scan = requests.get(scan_url).json()
    time.sleep(1)
    update = requests.get(update_url).json()
    update_scan = [
        x["scanq_length"] for x in update["entries"] if x["uuid"] == net_uuid_sel
    ]
    update_scan_num = update_scan[0]
    update_mux = [x["num_mux"] for x in update["entries"] if x["uuid"] == net_uuid_sel]
    update_mux_num = update_mux[0]
    orig_serv = [x["num_svc"] for x in update["entries"] if x["uuid"] == net_uuid_sel]
    orig_serv_num = orig_serv[0]
    update_serv_num = 0
    while update_scan_num > 0:
        update = requests.get(update_url).json()
        update_scan = [
            x["scanq_length"] for x in update["entries"] if x["uuid"] == net_uuid_sel
        ]
        update_scan_num = update_scan[0]
        update_serv = [
            x["num_svc"] for x in update["entries"] if x["uuid"] == net_uuid_sel
        ]
        update_serv_num = update_serv[0] - orig_serv_num
        update_scan_perc = 100 - (
            (float(update_scan_num) / float(update_mux_num)) * 100
        )
        update_stream = requests.get(stream_url).json()
        stream_freq_list = []
        stream_freq_list = [x.get("stream") for x in update_stream["entries"]]
        stream_freq = "  &  ".join(str(s) for s in stream_freq_list)
        pDialog.update(
            int(update_scan_perc),
            f"Buscando: {stream_freq}\nNovos serviços encontrados: {update_serv_num}",
        )
        time.sleep(1)
        if pDialog.iscanceled():
            mux_list_str = str(mux_list)
            mux_list_str = re.sub("u'", '"', mux_list_str)
            mux_list_str = re.sub("'", '"', mux_list_str)
            mux_stop_url = (
                "http://"
                + tvh_url
                + ":"
                + tvh_port
                + '/api/idnode/save?node={"scan_state":0,"uuid":'
                + mux_list_str
                + "}"
            )
            mux_stop = requests.get(mux_stop_url)
            dialog.ok("Busca cancelada", "Novos serviços não serão mapeados.")
            return
    pDialog.close()
    if update_serv_num == 0:
        dialog.ok(
            "Busca completa.",
            f"Novos serviços encontrados: {update_serv_num}.\n",
        )
        return
    goto_map = dialog.yesno(
        "Busca completa.",
        f"Novos serviços encontrados: {update_serv_num}.\nGostaria de mapear os canais para o Kodi ter acesso?",
    )
    if not goto_map:
        return
    map_all_services()


def select_network():
    api_path = "mpegts/network/grid"
    api_url = f"http://{tvh_url}:{tvh_port}/api/{api_path}"
    networks = requests.get(api_url).json()
    net_name = []
    net_uuid = []
    for net_n in networks["entries"]:
        net_name.append(net_n["networkname"])
    for net_u in networks["entries"]:
        net_uuid.append(net_u["uuid"])
    if len(net_name) == 1:
        return net_uuid[0]
    sel = dialog.select("Selecionar rede", list=net_name)
    if sel >= 0:
        return net_uuid[sel]
    else:
        return None


def mux_create(network_uuid, mfreq):
    mux_create_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/mux_create"
    data = {
        "uuid": network_uuid,
        "conf": json.dumps(
            {
                "enabled": 1,
                "epg": 1,
                "delsys": "DVB-C",
                "frequency": mfreq * 1000000,
                "symbolrate": "5217000",
                "constellation": "QAM/256",
                "fec": "AUTO",
                "plp_id": -1,
                "scan_state": 0,
                "charset": "ISO-8859-1",
                "tsid_zero": "false",
                "pmt_06_ac3": 0,
                "eit_tsid_nocheck": "false",
                "sid_filter": 0,
                "data_slice": 0,
            }
        ),
    }
    requests.post(mux_create_url, data=data)


def network_delete(uuid):
    network_delete_url = f"http://{tvh_url}:{tvh_port}/api/idnode/delete"
    data = {
        "uuid": json.dumps([uuid]),
    }
    requests.post(network_delete_url, data=data)


def network_create(name):
    network_create_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/network/create"
    data = {
        "class": "dvb_network_dvbc",
        "conf": json.dumps(
            {
                "networkname": name,
                "scanfile": "",
                "pnetworkname": "",
                "nid": 0,
                "autodiscovery": 1,
                "ignore_chnum": "false",
                "satip_source": 0,
                "charset": "ISO-8859-1",
                "skipinitscan": "true",
                "idlescan": "false",
                "sid_chnum": "false",
                "localtime": 0,
            }
        ),
    }

    requests.post(network_create_url, data=data)


def del_muxes():
    mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
    muxes = requests.get(mux_url).json()
    muxes_uuid = [x["uuid"] for x in muxes["entries"]]
    del_nodes(muxes_uuid)


@plugin.route("/conf_freq")
def conf_freq():
    network_uuid = select_network()
    if network_uuid:
        mfreq = dialog.input("Frequência em MHz: (Ex: 465)", type=xbmcgui.INPUT_NUMERIC)
        try:
            mfreq_num = int(mfreq)
            if mfreq_num >= 111 and mfreq_num <= 783:
                reset_channels(no_ask=True)
                del_muxes()

                mux_create(network_uuid, mfreq_num)
                # dialog.ok("Frequência adicionada!", "Frequência adicionada a rede.")
                scan_network(network_uuid)
            else:
                dialog.ok(
                    "Frequência inválida",
                    "Entre com frequência no intervalo 111 a 783 MHz.",
                )
        except:
            pass

    else:
        dialog.ok("Falha", "Configure rede no TVH.")


@plugin.route("/mux_scan")
def mux_scan():
    network_uuid = select_network()
    if network_uuid:
        scan_network(network_uuid)


def del_nodes(uuids):
    uuids_str = ",".join(f'"{x}"' for x in uuids)
    delete_node_url = f"http://{tvh_url}:{tvh_port}/api/idnode/delete"

    requests.post(delete_node_url, data={"uuid": f"[{uuids_str}]"})


def list_services():
    service_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/service/grid?start=0&limit=999999999&sort=svcname&dir=ASC"
    services = requests.get(service_url).json()
    return services


def list_channels():
    channels_url = f"http://{tvh_url}:{tvh_port}/api/channel/grid"

    channels = requests.post(
        channels_url,
        data={
            "start": "0",
            "limit": "999999999",
            "sort": "name",
            "dir": "ASC",
            "all": "1",
        },
    ).json()
    return channels


def del_freq_by_name(name):
    services = list_services()
    services_uuid = {}
    for sv_u in services["entries"]:
        services_uuid[sv_u["uuid"]] = sv_u

    channels = list_channels()
    num_chan_del = 0
    num_sv_del = 0
    del_uuids = []
    for ch_u in channels["entries"]:
        service = services_uuid[ch_u["services"][0]]
        if name in service["multiplex"]:
            del_uuids.append(ch_u["uuid"])
            num_chan_del += 1
    del_nodes(del_uuids)
    del_uuids = []
    for uuid in services_uuid:
        suid = services_uuid[uuid]
        if name in suid["multiplex"]:
            del_uuids.append(uuid)
            num_sv_del += 1
    del_nodes(del_uuids)

    return num_chan_del, num_sv_del


def map_services(mux):
    services = list_services()
    services_param = services_param_load()
    services_selected = []
    for sv in services["entries"]:
        if mux in sv["multiplex"]:
            services_selected.append(sv["uuid"])
    requests.post(
        f"http://{tvh_url}:{tvh_port}/api/service/mapper/save",
        data={
            "node": json.dumps(
                {
                    "services": json.dumps(services_selected),
                    **services_param,
                }
            )
        },
    )

    dialog.ok("Mapeados.", "Canais foram mapeados.")


@plugin.route("/mux_scan_freq")
def mux_scan_freq():
    network_uuid = select_network()
    if network_uuid:
        mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
        muxes = requests.get(mux_url).json()
        mux_list = [x for x in muxes["entries"] if x["network_uuid"] == network_uuid]
        list = [f'{x["network"]}/{x["name"]}' for x in mux_list]
        sel = dialog.select("Selecionar frequência:", list)
        if sel >= 0:
            mux = mux_list[sel]
            mux_name = mux["name"]
            if dialog.yesno(
                "Busca por frequência", "Apagar canais e serviços nesta frequência"
            ):
                del_freq_by_name(mux_name)
                time.sleep(1)
            pDialog = xbmcgui.DialogProgress()
            pDialog.create("Buscando canais...", "Por favor, aguarde...")

            data = requests.post(f"http://{tvh_url}:{tvh_port}/api/idnode/load", data={
                "uuid": mux["uuid"],
                "meta": 1
            }).json()["entries"][0].get("params")
            params = {}
            for x in data:
                params[x.get("id")] = x.get("value")

            payload = {
                "enabled": 1,
                "epg": 1,
                "epg_module_id": params.get("epg_module_id"),
                "delsys": params.get("delsys"),
                "frequency": params.get("frequency"),
                "symbolrate": params.get("symbolrate"),
                "constellation": params.get("constellation"),
                "fec": params.get("fec"),
                "plp_id": params.get("plp_id"),
                "scan_state": 3,
                "charset": params.get("charset"),
                "uuid": mux["uuid"]
                }

            requests.post(
                f"http://{tvh_url}:{tvh_port}/api/idnode/save",
                data={"node": json.dumps(payload)},
            )
            time.sleep(2)
            is_active = False
            while True:
                json_resp = requests.post(
                    f"http://{tvh_url}:{tvh_port}/api/idnode/load",
                    data={"uuid": json.dumps([mux["uuid"]]), "grid": 1},
                ).json()
                entry = json_resp["entries"][0]
                if pDialog.iscanceled():
                    pDialog.close()
                    break
                if entry["scan_state"] == 1:
                    time.sleep(1)
                    continue
                if not is_active and entry["scan_state"] == 2:
                    is_active = True
                    pDialog.update(50, f"Frequência: {mux_name}")
                    time.sleep(1)
                    continue
                if entry["scan_state"] == 0:
                    pDialog.update(100, "Busca finalizada!")
                    break
                time.sleep(1)
            update_serv_num = int(entry["num_svc"]) - int(entry["num_chn"])
            pDialog.close()
            if update_serv_num == 0:
                dialog.ok(
                    "Busca completa",
                    f"Serviços encontrados {entry['num_svc']}.\nNão há novos canais para serem mapeados",
                )
                return
            goto_map = dialog.yesno(
                "Busca completa.",
                f"Total de serviços: {entry['num_svc']}.\nNovos canais encontrados: {update_serv_num}.\nGostaria de mapeá-los para Kodi ter acesso?",
            )

            if not goto_map:
                return

            map_services(mux_name)


@plugin.route("/reset_channels")
def reset_channels(no_ask=False):
    network_uuid = select_network()
    if network_uuid and (
        no_ask or dialog.yesno("Apagar canais", "Deseja apagar todos os canais?")
    ):
        xbmc.log("resetando canais", xbmc.LOGINFO)
        channels_url = (
            "http://"
            + tvh_url
            + ":"
            + tvh_port
            + "/api/channel/grid?all=1&limit=999999999&sort=name"
        )
        channels = list_channels()
        channels_uuid = []
        for ch_u in channels["entries"]:
            channels_uuid.append(ch_u["uuid"])
        del_nodes(channels_uuid)
        time.sleep(1)
        services = list_services()
        services_uuid = []
        for sv_u in services["entries"]:
            services_uuid.append(sv_u["uuid"])

        del_nodes(services_uuid)

        if not no_ask:
            dialog.ok("Finalizado.", "Canais foram apagados!")


@plugin.route("/reset_channels_freq")
def reset_channels_freq():
    network_uuid = select_network()
    if network_uuid:
        mux_url = f"http://{tvh_url}:{tvh_port}/api/mpegts/mux/grid?start=0&limit=999999999&sort=name&dir=ASC"
        muxes = requests.get(mux_url).json()
        mux_list = [x for x in muxes["entries"] if x["network_uuid"] == network_uuid]
        list = [f'{x["network"]}/{x["name"]}' for x in mux_list]
        opt = dialog.select("Apagar canais em: ", list)
        if opt >= 0:
            name = mux_list[opt]["name"]
            num_chan_del, num_sv_del = del_freq_by_name(name)
            dialog.ok(
                "Finalizado.",
                f"{num_chan_del} canais apagados.\n({num_sv_del}) serviços apagados.\n",
            )


grab_bool_epg = False
map_bool_epg = False
pDialog = xbmcgui.DialogProgress()

@plugin.route("/run_epg_grabber")
def run_epg_grabber(title):
    global grab_bool_epg, pDialog
    enable_xmltv()
    poll_url = f"http://{tvh_url}:{tvh_port}/comet/poll"
    poll_data = requests.get(poll_url).json()
    boxid = poll_data.get("boxid")

    i = 0
    message_array = []
    percent = 0
    refresh_epg_url = f"http://{tvh_url}:{tvh_port}/api/epggrab/internal/rerun?rerun=1"
    refresh_epg = requests.get(refresh_epg_url).json()
    if refresh_epg == {}:
        pDialog.create(title)
        while True:
            data = requests.get(f"{poll_url}?boxid={boxid}&immediate=0").json()
            xbmc.log(json.dumps(data), xbmc.LOGINFO)
            for message in data.get("messages"):
                if message.get("notificationClass") == "logmessage":
                    text = message.get("logtxt")
                    message_array.append(text)
                    message_text = "\n".join(message_array)
                    if "parse" in text:
                        percent = 10
                    elif "channels" in text:
                        percent = 30
                    elif "seasons" in text:
                        percent = 60
                    elif "episodes" in text:
                        percent = 90
                    elif "broadcast" in text:
                        percent = 100
                    elif (
                        "no output detected" in text or "grab returned no data" in text
                    ):
                        pDialog.close()
                        return

                    pDialog.update(percent, message_text)

                    if percent == 100:
                        pDialog.update(percent, "Baixado com sucesso!")
                        time.sleep(2)
                        pDialog.close()
                        grab_bool_epg = True
                        return
            i += 1
            if pDialog.iscanceled() or i == 30:
                return
            time.sleep(1)


def enable_xmltv():
    list_url = f"http://{tvh_url}:{tvh_port}/api/epggrab/module/list"
    epg_modules = requests.get(list_url).json()
    uuid = None
    for entry in epg_modules.get("entries"):
        if "Internal: XMLTV" in entry.get("title"):
            if "epggrabmodNone" in entry.get("status"):
                uuid = entry.get("uuid")
            break

    if uuid:
        save_node_url = f"http://{tvh_url}:{tvh_port}/api/idnode/save"
        nodes = {
            "enabled": True,
            "priority": 3,
            "args": "",
            "dn_chnum": 0,
            "scrape_extra": False,
            "scrape_onto_desc": False,
            "use_category_not_genre": False,
            "uuid": uuid,
        }
        requests.post(save_node_url, data={"node": json.dumps(nodes)})


def map_epg(map_url):
    global map_bool_epg
    enable_xmltv()
    epggrab_url = f"http://{tvh_url}:{tvh_port}/api/epggrab/channel/grid"
    resp = requests.post(
        epggrab_url,
        data={"sort": "id", "dir": "ASC", "all": "1", "start": 0, "limit": 999999999},
    ).json()

    map2epg = {}
    pDialog.create("Etapa 2: Mapeando")

    for epg in resp["entries"]:
        epg["channels"] = []
        map2epg[epg["id"].strip()] = epg

    map_chan_id = requests.get(map_url).json()

    channels = list_channels()
    for ch in channels["entries"]:
        epg_id = map_chan_id.get(ch["name"].strip().lower(), None)
        if epg_id:
            epg = map2epg.get(epg_id, None)
            if epg:
                epg["channels"].append(ch["uuid"])

    save_node_url = f"http://{tvh_url}:{tvh_port}/api/idnode/save"
    nodes = []

    for _id, epg in map2epg.items():
        nodes.append({"uuid": epg["uuid"], "channels": epg["channels"]})

    requests.post(save_node_url, data={"node": json.dumps(nodes)})

    map_bool_epg = True
    pDialog.close()


def disable_update_display_name():
    url = f"http://{tvh_url}:{tvh_port}/api/epggrab/config/load"
    entry = requests.get(url).json().get("entries")[0]
    payload = {}
    for param in entry.get("params"):
        param_id = param.get("id")
        if param_id == "channel_rename":
            payload[param_id] = False
        else:
            payload[param_id] = param.get("value")

    url = f"http://{tvh_url}:{tvh_port}/api/epggrab/config/save"
    requests.post(url, data={
        "node": json.dumps(payload)
    });

@plugin.route("/set_epg_source")
def set_epg_source():
    enable_xmltv()
    disable_update_display_name()
    epg_source_url = "https://gist.githubusercontent.com/rootcoder/0cad88e01181c023987d429ec1675a87/raw/epg.json"
    epg_source_array = requests.get(epg_source_url).json()

    tvheadend = xbmcaddon.Addon("service.tvheadend43")

    xmltv_type = tvheadend.getSetting("XMLTV_TYPE")
    location_web = None
    if xmltv_type == "WEB":
        location_web = tvheadend.getSetting("XMLTV_LOCATION_WEB")

    selected_source = -1
    source_ids = []

    for index in range(len(epg_source_array)):
        source = epg_source_array[index]
        if xmltv_type == "WEB" and source.get("url") == location_web:
            selected_source = index
        source_ids.append(f"{source.get('id')}: {source.get('url')}")

    opt_select = dialog.select(
        "Selecionar fonte epg: ", source_ids, preselect=selected_source
    )

    if opt_select >= 0:
        source = epg_source_array[opt_select]
        if selected_source != opt_select:
            path_tvheadend43 = xbmcvfs.translatePath(tvheadend.getAddonInfo("profile"))
            settings = os.path.join(path_tvheadend43, "settings.xml")
            lines = []
            with open(settings, "r", encoding="utf-8") as f:
                for line in f.readlines():
                    if "XMLTV_TYPE" in line:
                        line = '    <setting id="XMLTV_TYPE">WEB</setting>\n'
                    elif "XMLTV_LOCATION_WEB" in line:
                        line = f'    <setting id="XMLTV_LOCATION_WEB">{source.get("url")}</setting>\n'
                    lines.append(line)

            with open(settings, "w", encoding="utf-8") as f:
                for line in lines:
                    f.write(line)
        run_epg_grabber("Etapa 1: Baixando EPG id")
        if not grab_bool_epg:
            dialog.ok("Falha.", "Falha ao carregar EPG!")
            return

        map_epg(source.get("map"))

        if not map_bool_epg:
            dialog.ok("Falha.", "Falha ao mapear EPG!")
            return

        run_epg_grabber("Etapa 3: Baixando EPG...")

        subprocess.run(
            ["systemctl", "restart", "service.tvheadend43"],
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["systemctl", "restart", "pvr.hts"],
            capture_output=True,
            text=True,
        )
        dialog.ok("EPG", "EPG mapeado e carregado!")


@plugin.route("/")
def index():
    items = []
    items.append(
        {
            "label": "Aplicar picons aos canais (by josemoraes99)",
            "path": plugin.url_for("picons"),
            "thumbnail": get_icon_path("adapter"),
        }
    )
    items.append(
        {
            "label": "Busca de canais",
            "path": plugin.url_for("conf_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Busca de canais por frequência",
            "path": plugin.url_for("mux_scan_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    # items.append(
    #     {
    #         "label": "Busca de canais nas frequências",
    #         "path": plugin.url_for("mux_scan"),
    #         "thumbnail": get_icon_path("frequency"),
    #     }
    # )
    items.append(
        {
            "label": "Apagar todos canais",
            "path": plugin.url_for("reset_channels"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Apagar canais por frequência",
            "path": plugin.url_for("reset_channels_freq"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Mapear serviços para acesso do kodi",
            "path": plugin.url_for("map_all_services"),
            "thumbnail": get_icon_path("frequency"),
        }
    )
    items.append(
        {
            "label": "Selecionar fonte EPG e mapear",
            "path": plugin.url_for("set_epg_source"),
            "thumbnail": get_icon_path("list"),
        }
    )
    # items.append(
    #     {
    #         "label": "Recarregar EPG",
    #         "path": plugin.url_for("run_epg_grabber"),
    #         "thumbnail": get_icon_path("list"),
    #     }
    # )
    # items.append(
    #     {
    #         "label": "Mapear canais com respectivo EPG id",
    #         "path": plugin.url_for("map_epg"),
    #         "thumbnail": get_icon_path("list"),
    #     }
    # )
    return items


if __name__ == "__main__":
    plugin.run()

