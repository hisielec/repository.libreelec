import sys
import urllib
import urllib.parse
import xbmcgui
import xbmc
import xbmcplugin

from resources.lib.modules import cleaner

plugin_handle = int(sys.argv[1])
kodi_base_url = sys.argv[0]


def build_url(query):
    return f"{kodi_base_url}?{urllib.parse.urlencode(query)}"


def create_dir(
    name,
    mode,
    image,
):
    u = build_url(
        {
            "mode": mode,
        }
    )
    liz = xbmcgui.ListItem(name)

    liz.setArt({"thumb": image})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    xbmcplugin.addDirectoryItem(
        handle=plugin_handle, url=u, listitem=liz, isFolder=False
    )


def show_menu():
    xbmc.executebuiltin("Container.SetViewMode(500)")
    create_dir("Limpar cache", "clean_cache", cleaner.get_image("folder_clean.png"))
    create_dir(
        "Limpar thumbnails", "clean_thumb", cleaner.get_image("folder_clean.png")
    )
    create_dir(
        "Limpar pacotes", "clean_packages", cleaner.get_image("folder_clean.png")
    )
    xbmcplugin.endOfDirectory(plugin_handle)


def router(params_str):
    params = dict(urllib.parse.parse_qsl(params_str))
    mode = params.get("mode")

    if mode == None:
        show_menu()
    elif mode == "clean_cache":
        cleaner.clean_cache()
    elif mode == "clean_thumb":
        cleaner.clean_thumb()
    elif mode == "clean_packages":
        cleaner.clean_packages()


if __name__ == "__main__":
    router(sys.argv[2][1:])