# JellyCon

JellyCon is a lightweight Kodi addon that lets you browse and play media files from your Jellyfin server directly within the Kodi interface.

## License

JellyCon is licensed under the terms of the [GPLv2](LICENSE.txt).
